const { InfluxDB, Point } = require("@influxdata/influxdb-client");

const influxDB = new InfluxDB({
  url: process.env.INFLUXDB_URL,
  token: process.env.INFLUXDB_TOKEN,
  timeout: 120000,
});

const writeApi = influxDB.getWriteApi(
  process.env.INFLUXDB_ORG,
  process.env.INFLUXDB_BUCKET
);

const writeApiPool = influxDB.getWriteApi(
  process.env.INFLUXDB_ORG,
  process.env.INFLUXDB_POOL_BUCKET
);

writeApiPool.writeOptions.writeFailed = (err, lines) => {
  console.error('Write failed', err);
};

module.exports = { influxDB, writeApi, writeApiPool, Point };
