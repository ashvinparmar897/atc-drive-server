const { createClient } = require("redis");

// Create Redis client with proper error handling
const redisClient = createClient({
  url: process.env.REDIS_URL || "redis://localhost:6379",
  socket: {
    reconnectStrategy: (retries) => {
      if (retries > 5) {
        console.log("Too many retries on Redis. Connection terminated");
        return new Error("Redis connection failed");
      }
      return Math.min(retries * 100, 5000); // Reconnect with backoff
    },
  },
});

const redisClientRead = createClient({
  url: process.env.REDIS_URL || "redis://localhost:6379",
  socket: {
    reconnectStrategy: (retries) => {
      if (retries > 5) {
        console.log("Too many retries on Redis. Connection terminated");
        return new Error("Redis connection failed");
      }
      return Math.min(retries * 100, 5000); // Reconnect with backoff
    },
  },
});

// Handle connection events
redisClient.on("error", (err) => console.log("Redis Client Error", err));
redisClient.on("connect", () => console.log("Redis Client Connected"));
redisClient.on("ready", () => console.log("Redis Client Ready"));
redisClient.on("reconnecting", () => console.log("Redis Client Reconnecting"));
redisClient.on("end", () => console.log("Redis Client Connection Closed"));

// Handle connection events
redisClientRead.on("error", (err) => console.log("Redis READ Client Error", err));
redisClientRead.on("connect", () => console.log("Redis READ Client Connected"));
redisClientRead.on("ready", () => console.log("Redis READ Client Ready"));
redisClientRead.on("reconnecting", () => console.log("Redis READ Client Reconnecting"));
redisClientRead.on("end", () => console.log("Redis READ Client Connection Closed"));

// Connect to Redis
(async () => {
  try {
    await redisClient.connect();
  } catch (err) {
    console.error("Redis WRITE connection failed:", err);
  }
})();

// Connect to Redis
(async () => {
  try {
    await redisClientRead.connect();
  } catch (err) {
    console.error("Redis READ connection failed:", err);
  }
})();

module.exports = {
  redisClient,
  redisClientRead,
};
