"use strict";

const fs = require("fs");
const path = require("path");
const Sequelize = require("sequelize");
const process = require("process");
const basename = path.basename(__filename);

const env = process.env.NODE_ENV || "development";
const config = require(path.join(__dirname, "config.js"))[env];
const modelsPath = path.join(__dirname, "../models");
const db = {};

let sequelize;
if (config.use_env_variable) {
  sequelize = new Sequelize(process.env[config.use_env_variable], {
    ...config,
    pool: {
      max: 50,                    
      min: 10,                    
      acquire: 60000,             
      idle: 10000,               
      evict: 10000,               
    },
    retry: {
      max: 5,                     
      match: [
        /ConnectionError/,
        /SequelizeConnectionError/,
        /SequelizeConnectionRefusedError/,
        /SequelizeHostNotFoundError/,
        /SequelizeHostNotReachableError/,
        /SequelizeInvalidConnectionError/,
        /SequelizeConnectionTimedOutError/,
        /SequelizeConnectionAcquireTimeoutError/
      ],
      timeout: 30000              
    },
    dialectOptions: {
      connectTimeout: 30000       
    },
    logging: (msg) => {
      if (msg.includes("ERROR") || msg.includes("error")) {
        console.log(msg);
      }
    },
  });
} else {
  sequelize = new Sequelize(config.database, config.username, config.password, {
    ...config,
    pool: {
      max: 50,                    
      min: 10,                    
      acquire: 60000,             
      idle: 10000,                
      evict: 10000,               
    },
    retry: {
      max: 5,                     
      match: [
        /ConnectionError/,
        /SequelizeConnectionError/,
        /SequelizeConnectionRefusedError/,
        /SequelizeHostNotFoundError/,
        /SequelizeHostNotReachableError/,
        /SequelizeInvalidConnectionError/,
        /SequelizeConnectionTimedOutError/,
        /SequelizeConnectionAcquireTimeoutError/
      ],
      timeout: 30000              
    },
    dialectOptions: {
      connectTimeout: 30000       
    },
    logging: (msg) => {
      if (msg.includes("ERROR") || msg.includes("error")) {
        console.log(msg);
      }
    },
  });
}

// Test the database connection
async function testConnection() {
  try {
    await sequelize.authenticate();
    console.log("Connection has been established successfully.");
  } catch (error) {
    console.error("Unable to connect to the database:", error);
    process.exit(1);
  }
}

// Load models
fs.readdirSync(modelsPath)
  .filter((file) => {
    return (
      file.indexOf(".") !== 0 &&
      file !== basename &&
      file.slice(-3) === ".js" &&
      file.indexOf(".test.js") === -1
    );
  })
  .forEach((file) => {
    const model = require(path.join(modelsPath, file))(
      sequelize,
      Sequelize.DataTypes
    );
    db[model.name] = model;
  });

// Setup associations
Object.keys(db).forEach((modelName) => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

// Synchronize all models
async function syncDatabase(options = {}) {
  try {
    // Use { force: true } to drop tables and recreate (for development)
    // Use { alter: true } to sync tables without dropping (safer for production)
    const syncOptions = { ...options };

    // For production, you might want to check if tables exist first
    if (process.env.NODE_ENV === "production") {
      syncOptions.alter = true;
    }

    await sequelize.sync(syncOptions);
  } catch (error) {
    console.error("Error synchronizing models:", error);
    throw error;
  }
}

// Assign to db object
db.sequelize = sequelize;
db.Sequelize = Sequelize;
db.testConnection = testConnection;
db.syncDatabase = syncDatabase;

// You can now call these functions when needed:
// await db.testConnection();
// await db.syncDatabase({ alter: true });

setInterval(async () => {
  try {
    await sequelize.query('SELECT 1');
  } catch (error) {
    console.error('Database connection health check failed:', error);
  }
}, 30000);

module.exports = db;
