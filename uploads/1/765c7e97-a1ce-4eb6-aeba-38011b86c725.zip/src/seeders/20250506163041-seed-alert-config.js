'use strict';

module.exports = {
  async up(queryInterface) {
    const records = [
      { field: 'temperature_t1', displayName: 'Temperature T1', conditionType: 'min', value: 40, enabled: true, createdAt: new Date(), updatedAt: new Date() },
      { field: 'temperature_t1', displayName: 'Temperature T1', conditionType: 'max', value: 55, enabled: true, createdAt: new Date(), updatedAt: new Date() },
      { field: 'pressure_p1', displayName: 'Pressure P1', conditionType: 'max', value: 1.6, enabled: true, createdAt: new Date(), updatedAt: new Date() },
      { field: 'pressure_p1', displayName: 'Pressure P1', conditionType: 'min', value: 0.5, enabled: true, createdAt: new Date(), updatedAt: new Date() },
      { field: 'pressure_p2', displayName: 'Pressure P2', conditionType: 'max', value: 1.6, enabled: true, createdAt: new Date(), updatedAt: new Date() },
      { field: 'pressure_p2', displayName: 'Pressure P2', conditionType: 'min', value: 0.5, enabled: true, createdAt: new Date(), updatedAt: new Date() },
      { field: 'pressure_p5', displayName: 'Pressure P5', conditionType: 'max', value: 3.3, enabled: true, createdAt: new Date(), updatedAt: new Date() },
      { field: 'filter_pressure_diff', displayName: 'Filter Pressure Diff', conditionType: 'max', value: 0.7, enabled: true, createdAt: new Date(), updatedAt: new Date() },
      { field: 'inverter_status', displayName: 'Inverter Status', conditionType: 'notEquals', value: 0, enabled: true, createdAt: new Date(), updatedAt: new Date() },
    ];

    // Add dynamic electric_meter entries
    for (let meterNum = 1; meterNum <= 6; meterNum++) {
      for (let lineNum = 1; lineNum <= 3; lineNum++) {
        records.push({
          field: `electric_meter${meterNum}_voltage_l${lineNum}`,
          displayName: `Meter ${meterNum} Voltage${lineNum}`,
          conditionType: 'min',
          value: 380,
          enabled: true,
          createdAt: new Date(),
          updatedAt: new Date(),
        });
      }
    }

    await queryInterface.bulkInsert('alert_configs', records, {});
  },

  async down(queryInterface) {
    await queryInterface.bulkDelete('alert_configs', null, {});
  }
};
