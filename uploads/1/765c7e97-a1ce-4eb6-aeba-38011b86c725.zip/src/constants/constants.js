const FIXED_PRICE = "Fixed";

const USD_CURRENCY = "USD";

const EUR_CURRENCY = "EUR";

const BINANCE_BITCOIN_API_URL = process.env.BINANCE_BITCOIN_API_URL;
const COINGECKO_BITCOIN_API_URL = process.env.COINGECKO_BITCOIN_API_URL;
const HASHRATE_API_URL = process.env.HASHRATE_API_URL;
const HASHRATE_API_KEY = process.env.HASHRATE_API_KEY;
const MINING_POOL_FEES = process.env.MINING_POOL_FEES;

const GASUM_API_URL = process.env.GASUM_API_URL;
const GASUM_LOGIN_USERNAME = process.env.GASUM_LOGIN_USERNAME;
const GASUM_LOGIN_PASSWORD = process.env.GASUM_LOGIN_PASSWORD;
const GASUM_LOGIN_SUBSCRIPTION_KEY = process.env.GASUM_LOGIN_SUBSCRIPTION_KEY;
const GASUM_PER_MINUTE_TIME_SERIES_ID = process.env.GASUM_PER_MINUTE_TIME_SERIES_ID
const GASUM_SCHEDULED_TIME_SERIES_ID = process.env.GASUM_SCHEDULED_TIME_SERIES_ID

const RABBITMQ_URL = process.env.RABBITMQ_URL;
const CONTAINER_POWER_CONSUMPTION_QUEUE_NAME = process.env.CONTAINER_POWER_CONSUMPTION_QUEUE_NAME;

const METRIC_TRANSLATIONS = {
  温度: "temperature",
  湿度: "humidity",
  压力P1: "pressure_p1",
  压力P2: "pressure_p2",
  压力P3: "pressure_p3",
  压力P4: "pressure_p4",
  压力P5: "pressure_p5",
  供回液压差: "hydraulic_pressure_diff",
  过滤器压差: "filter_pressure_diff",
  温度T1: "temperature_t1",
  温度T2: "temperature_t2",
  备用温度T3: "temperature_t3",
  备用温度T4: "temperature_t4",
  当前频率: "frequency",
  变频器状态w: "inverter_status",
  过滤器压差绝对值: "abs_filter_pressure_diff",
  电压L1: "voltage_l1",
  电压L2: "voltage_l2",
  电压L3: "voltage_l3",
  电流L1: "current_l1",
  电流L2: "current_l2",
  电流L3: "current_l3",
};

module.exports = {
  FIXED_PRICE,
  USD_CURRENCY,
  EUR_CURRENCY,
  BINANCE_BITCOIN_API_URL,
  HASHRATE_API_KEY,
  HASHRATE_API_URL,
  MINING_POOL_FEES,
  GASUM_API_URL,
  GASUM_LOGIN_PASSWORD,
  GASUM_LOGIN_USERNAME,
  GASUM_LOGIN_SUBSCRIPTION_KEY,
  CONTAINER_POWER_CONSUMPTION_QUEUE_NAME,
  RABBITMQ_URL,
  METRIC_TRANSLATIONS,
  GASUM_PER_MINUTE_TIME_SERIES_ID,
  GASUM_SCHEDULED_TIME_SERIES_ID,
  COINGECKO_BITCOIN_API_URL
};
