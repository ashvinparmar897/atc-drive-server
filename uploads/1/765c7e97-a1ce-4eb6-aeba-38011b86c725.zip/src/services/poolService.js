const fetch = require("isomorphic-fetch");
const { getYesterdayUTCDateString } = require("../utils/utils");

const getPoolsRevenue = async () => {
  const token = process.env.LUXOR_API_KEY;
  const baseUrl = process.env.LUXOR_API_URL;

  const dateString = getYesterdayUTCDateString();

  const subaccounts = ["kemi"];
  const url = `${baseUrl}/BTC?start_date=${dateString}&end_date=${dateString}&subaccount_names=${encodeURIComponent(subaccounts.join(","))}`;

  try {
    const response = await fetch(url, {
      method: "GET",
      headers: {
        authorization: token,
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("📝 Response body:", errorText);
      return;
    }
    const data = await response.json();
    return data.revenue;
  } catch (error) {
    console.error("❌ An error occurred while fetching revenue data:", error);
  }
};

module.exports = {
  getPoolsRevenue
};
