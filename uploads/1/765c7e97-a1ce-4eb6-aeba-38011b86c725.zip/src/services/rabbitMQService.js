const amqp = require("amqplib");
const Log_Queue_Name = process.env.RABBITMQ_LOG_QUEUE_NAME;
const Pool_Queue_Name = process.env.RABBITMQ_POOL_QUEUE_NAME;
const RABBITMQ_URL = process.env.RABBITMQ_URL;
const {
  parseAndValidateMessage,
  // hasAllPowerKeys,
  mergeDeviceData,
  POWER_KEYS,
  ipToContainerMap,
  sendAlertEmailToAdmin
} = require("../utils/utils");
const { latestDeviceData } = require("./powerService");

const { combineAndStoreData } = require("../processors/dataStorageService");
const { processMinerLog } = require("../processors/logProcessor");
const { processPoolData } = require("../processors/poolProcessor");
const { sequelize, writeApi, writeApiPool } = require("../config");
const { setPoolData, getPoolData } = require("./redisServices");
const { storePoolDataInflux } = require("./influxService");

let rabbitConnection = null;
let rabbitChannel = null;
const accumulatedDeviceData = new Map();

const logsCache = new Map();
// const poolsCache = new Map();


let lastMessageTimestamp = Date.now();
let lastAlertTimestamp = null;

const MAX_INACTIVITY_MS = 1 * 60 * 1000;   // ⏰ 1 minute of no data triggers alert
const ALERT_COOLDOWN_MS = 15 * 60 * 1000;  // 🕒 15 minutes cooldown between alerts


setInterval(async () => {
  const now = Date.now();
  const timeSinceLastMessage = now - lastMessageTimestamp;

  const shouldSendAlert =
    timeSinceLastMessage > MAX_INACTIVITY_MS &&
    (!lastAlertTimestamp || now - lastAlertTimestamp > ALERT_COOLDOWN_MS);

  if (shouldSendAlert) {
    lastAlertTimestamp = now;

    const lastSeen = new Date(lastMessageTimestamp).toISOString();
    await sendAlertEmailToAdmin(
      "🚨 Alert: No Modbus Data in RabbitMQ (1 Minute Inactivity)",
      `<p>No data has been received in the Modbus RabbitMQ queue since <b>${lastSeen}</b>.</p>
       <p>This alert was triggered after 1 minute of inactivity. Further alerts will be spaced 15 minutes apart if the issue continues.</p>`,
      `No data received in Modbus queue since ${lastSeen}.`
    );
  }
}, 60 * 1000); // check every 1 minute


async function matchLogWithPoolAndStore(macAddress, maxRetryAttempts = 3) {
  if (!logsCache.has(macAddress)) return;

  const associatedPoolData = await getPoolData(macAddress);
  const minerData = {
    ...logsCache.get(macAddress),
    pool_info: associatedPoolData ?? [],
  }

  let lastProcessingError;

  for (let attempt = 1; attempt <= maxRetryAttempts; attempt++) {
    try {
      if (minerData?.mac_address) {
        await combineAndStoreData({
          ...logsCache.get(macAddress),
          pool_info: associatedPoolData ?? [],
        });
        logsCache.delete(macAddress);
      }
      return;
    } catch (error) {
      lastProcessingError = error;
      console.error(`Attempt ${attempt} failed for MAC ${macAddress}:`, error);

      if (attempt < maxRetryAttempts) {
        await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
      }
    }
  }
  console.error(`All attempts failed to process log with MAC ${macAddress}:`, lastProcessingError);
}

async function connectRabbitMQ() {
  if (rabbitConnection && rabbitChannel) return;

  try {
    rabbitConnection = await amqp.connect(RABBITMQ_URL);
    rabbitChannel = await rabbitConnection.createChannel();
    console.log("✅ RabbitMQ connected.");
  } catch (error) {
    console.error("❌ RabbitMQ connection failed:", error);
    // process.exit(1); // Exit process if connection fails
  }
}

async function startRabbitMQ() {
  try {
    if (!rabbitChannel) {
      await connectRabbitMQ();
    }

    console.log("RabbitMQ connected. Starting consumer...");

    rabbitChannel.consume(process.env.RABBITMQ_MODBUS_CONTAINER_POWER_DATA_QUEUE_NAME, async (message) => {
      try {
        lastMessageTimestamp = Date.now();
        const content = parseAndValidateMessage(message?.content?.toString());
        if (!content) return rabbitChannel.ack(message);

        // if (hasAllPowerKeys(content.cruxData)) {
        //   latestDeviceData.set(content?.deviceName, content);
        // }

        // const currentData =
        //   accumulatedDeviceData.get(content?.deviceName) || {};

        // const mergedData = mergeDeviceData(currentData, content);

        // accumulatedDeviceData.set(content?.deviceName, mergedData);

        // rabbitChannel.ack(message);
        for (const [ip, containerData] of Object.entries(content?.data)) {
          const thirdOctet = ip?.split?.('.')?.[2];
          const deviceName = ipToContainerMap?.[thirdOctet] || `Unknown Container (${ip})`;

          const totalPower = POWER_KEYS?.reduce((sum, key) => {
            const value = containerData?.[key];
            return sum + (value ? parseFloat(value) : 0);
          }, 0);

          const container = {
            deviceName,
            totalPower: totalPower?.toFixed(2),
            cruxData: Object.entries(containerData)?.map(([name, value]) => ({
              name,
              value: value !== null ? value?.toString() : null
            })),
          };

          if (POWER_KEYS?.some(key => containerData[key] !== undefined)) {
            latestDeviceData.set(deviceName, container);
          }
          const currentData = accumulatedDeviceData.get(deviceName) || {};
          const mergedData = mergeDeviceData(currentData, container);
          accumulatedDeviceData.set(deviceName, mergedData);
        }

        rabbitChannel.ack(message);
      } catch (error) {
        console.error("Error processing message:", error);
        rabbitChannel.ack(message);
      }
    });
  } catch (error) {
    console.error("RabbitMQ initialization failed:", error);
    // process.exit(1);
  }
}

function getAndClearAccumulatedData() {
  const data = new Map(accumulatedDeviceData);
  accumulatedDeviceData.clear();
  return data;
}

async function fetchLogsAndPoolsData() {
  try {
    if (!rabbitChannel) {
      await connectRabbitMQ();
    }

    await rabbitChannel.assertQueue(Log_Queue_Name, { durable: true });
    await rabbitChannel.assertQueue(Pool_Queue_Name, { durable: true });

    rabbitChannel.consume(Log_Queue_Name, async (msg) => {
      try {
        const log = JSON.parse(msg.content.toString());
        const processedLog = processMinerLog(log);
        logsCache.set(log?.mac_address, processedLog);
        
        await matchLogWithPoolAndStore(log?.mac_address);
        rabbitChannel.ack(msg);
      } catch (error) {
        console.error("Error processing log:", error);
        rabbitChannel.nack(msg);
      }
    });

    rabbitChannel.consume(Pool_Queue_Name, async (msg) => {
      try {
        const pool = JSON.parse(msg.content.toString());
        const processedPool = processPoolData(pool);
        await setPoolData(pool?.mac_address, processedPool);
        try {
          await storePoolDataInflux(pool);
        } catch (error) {
          console.error("Error storing pool data in Redis:", error);
        }
        
        rabbitChannel.ack(msg);
      } catch (error) {
        console.error("Error processing pool:", error);
        rabbitChannel.nack(msg);
      }
    });

    console.log("✅ RabbitMQ consumers started.");
  } catch (error) {
    console.error("🚨 Error in fetchLogsAndPoolsData:", error);
  }
}

process.on("SIGINT", async () => {
  try {
    if (rabbitChannel) await rabbitChannel.close();
    if (rabbitConnection) await rabbitConnection.close();
    console.log("RabbitMQ connection closed gracefully");
    await writeApi.close();
    await writeApiPool.close();
    process.exit(1);
  } catch (error) {
    console.error("🚨 Error closing RabbitMQ connection:", error);
    process.exit(1);
  }
});

process.on('beforeExit', async () => {
  await sequelize?.close();
});

module.exports = {
  connectRabbitMQ,
  getAndClearAccumulatedData,
  fetchLogsAndPoolsData,
  startRabbitMQ,
};
