const AppError = require("../utils/appError");
const { Checklist, ChecklistResponse, User, sequelize, UserRole } = require("../config/database");
const { Op } = require("sequelize");
const moment = require('moment-timezone');

module.exports = {
    getChecklists: async () => {
        try {
            return await Checklist.findAll();
        } catch (error) {
            console.error('Error fetching checklists:', error);
            throw new AppError("Error fetching checklists", 500);
        }
    },

    getChecklistDetails: async (checklistId) => {
        try {
            const checklist = await Checklist?.findByPk(checklistId);

            if (!checklist) {
                throw new AppError('Checklist not found', 404);
            }

            return {
                ...checklist.toJSON(),
                sections: checklist.content || []
            };
        } catch (error) {
            console.error('Error fetching checklist details:', error);
            throw new AppError("Error fetching checklist details", 500);
        }
    },

    submitChecklistResponse: async (responseData) => {
        const transaction = await sequelize.transaction();
        try {
            const { checklist_id, answers, user_id } = responseData;
            const checklist = await Checklist.findByPk(checklist_id, { transaction });

            if (!checklist) {
                throw new AppError('Checklist not found', 404);
            }

            // Verify submission frequency
            const lastResponse = await ChecklistResponse.findOne({
                where: {
                    user_id,
                    checklist_id
                },
                order: [['completed_at', 'DESC']],
                transaction
            });

            if (lastResponse) {
                const now = new Date();
                const lastDate = new Date(lastResponse?.completed_at);
                const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
                const lastSubmissionDate = new Date(lastDate.getFullYear(), lastDate.getMonth(), lastDate.getDate());

                let canSubmit = true;

                switch (checklist.frequency) {
                    case 'daily': {
                        canSubmit = today > lastSubmissionDate;
                        break;
                    }
                    case 'weekly': {
                        const daysDiff = Math.floor((today - lastSubmissionDate) / (1000 * 60 * 60 * 24));
                        canSubmit = daysDiff >= 7;
                        break;
                    }
                    case 'quarterly': {
                        const monthsDiffQuarterly = (today.getFullYear() - lastSubmissionDate.getFullYear()) * 12 +
                            (today.getMonth() - lastSubmissionDate.getMonth());
                        canSubmit = monthsDiffQuarterly >= 3;
                        break;
                    }
                    case 'half-yearly': {
                        const monthsDiffHalfYearly = (today.getFullYear() - lastSubmissionDate.getFullYear()) * 12 +
                            (today.getMonth() - lastSubmissionDate.getMonth());
                        canSubmit = monthsDiffHalfYearly >= 6;
                        break;
                    }
                }

                if (!canSubmit) {
                    throw new AppError(`You can only submit this ${checklist?.frequency.replace('-', ' ')} checklist once per period`, 400);
                }
            }

            const responseContent = checklist?.content.map(section => {
                const sectionAnswer = answers?.find(a => a?.section_id === section?.id);

                return {
                    ...section,
                    section_checked: sectionAnswer?.section_checked || false,
                    section_comment: sectionAnswer?.section_comment || null,
                    questions: section?.questions?.map(question => ({
                        ...question,
                        is_checked: sectionAnswer?.section_checked || false,
                        updated_by: user_id
                    }))
                };
            });

            const response = await ChecklistResponse.create({
                checklist_id,
                user_id,
                completed_at: new Date(),
                content: responseContent
            }, { transaction });

            await transaction.commit();
            return response;
        } catch (error) {
            await transaction.rollback();
            console.error('Error submitting checklist response:', error);
            throw error instanceof AppError ? error : new AppError("Error submitting checklist response", 500);
        }
    },

    getUserChecklistResponses: async (userId, checklistId, filters = {}) => {
        try {
            const { startDate, endDate, page = 1, pageSize = 10 } = filters;
            const offset = (page - 1) * pageSize;
            const whereClause = {
                user_id: userId,
                checklist_id: checklistId
            };

            if (startDate && endDate) {
                whereClause.completed_at = {
                    [Op.between]: [
                        moment(startDate).startOf('day').toDate(),
                        moment(endDate).endOf('day').toDate()
                    ]
                };
            }

            const { count, rows } = await ChecklistResponse.findAndCountAll({
                where: whereClause,
                order: [['completed_at', 'DESC']],
                include: [{
                    model: Checklist,
                    as: 'checklist',
                    attributes: ['id', 'name', 'frequency']
                }],
                limit: parseInt(pageSize),
                offset: parseInt(offset)
            });

            return { count, rows };
        } catch (error) {
            console.error('Error fetching user checklist responses:', error);
            throw new AppError("Error fetching user checklist responses", 500);
        }
    },

    getChecklistResponseDetails: async (responseId) => {
        try {
            const response = await ChecklistResponse.findByPk(responseId, {
                attributes: ['id', 'checklist_id', 'user_id', 'completed_at', 'content'],
                include: [
                    {
                        model: User,
                        as: 'user',
                        attributes: ['id', 'name', 'email']
                    },
                    {
                        model: Checklist,
                        as: 'checklist',
                        attributes: ['id', 'name', 'frequency']
                    }
                ]
            });

            if (!response) {
                throw new AppError('Checklist response not found', 404);
            }
            const answers = [];
            if (response.content && Array.isArray(response?.content)) {
                for (const section of response.content) {
                    if (section.questions && Array.isArray(section?.questions)) {
                        for (const question of section.questions) {
                            answers.push({
                                question_id: question?.id,
                                is_checked: question?.is_checked || false,
                                comment: question?.comment || null,
                                updated_by: question?.updated_by
                            });
                        }
                    }
                }
            }

            return {
                id: response.id,
                checklist_id: response?.checklist_id,
                user: response?.user,
                checklist: response?.checklist,
                completed_at: response?.completed_at,
                content: response?.content,
                answers
            };
        } catch (error) {
            console.error('Error fetching checklist response details:', error);
            throw new AppError("Error fetching checklist response details", 500);
        }
    },

    updateChecklistAnswers: async (responseId, updates, userId) => {
        const transaction = await sequelize.transaction();
        try {
            const response = await ChecklistResponse.findByPk(responseId, {
                include: [{
                    model: User,
                    as: 'user'
                }],
                transaction
            });

            if (!response) {
                throw new AppError('Response not found', 404);
            }
            if (response.user_id !== userId) {
                const user = await User.findOne({
                    where: { id: userId },
                    include: [{
                        model: UserRole,
                        as: 'role'
                    }],
                    transaction
                });
                if (!user || user?.role?.name !== 'Admin') {
                    throw new AppError('Only admin can update other users answers', 403);
                }
            }
            const updatesMap = new Map();
            updates?.forEach(update => {
                updatesMap?.set(update?.section_id, update);
            });

            const updatedContent = response.content.map(section => {
                const update = updatesMap?.get(section?.id);
                if (!update) return section;

                const updatedQuestions = section?.questions?.map(question => {
                    const questionUpdate = update?.questions?.find(q => q?.question_id === question?.id);
                    return {
                        ...question,
                        is_checked: questionUpdate?.is_checked ?? question.is_checked,
                        comment: questionUpdate?.comment ?? question.comment,
                        updated_by: userId
                    };
                });

                return {
                    ...section,
                    section_checked: update?.section_checked ?? section?.section_checked,
                    section_comment: update?.section_comment ?? section?.section_comment,
                    questions: updatedQuestions ?? section.questions
                };
            });
            await response.update({
                content: updatedContent,
                updated_by: userId
            }, { transaction });

            await transaction.commit();
            return response;
        } catch (error) {
            await transaction.rollback();
            console.error('Error updating checklist answers:', error);
            throw error instanceof AppError ? error : new AppError("Error updating checklist answers", 500);
        }
    },
    
    getUsersWithChecklists: async (filters = {}) => {
        try {
            const { frequency, startDate, endDate, page = 1, pageSize = 10, userId } = filters;
            const offset = (page - 1) * pageSize;
            const whereConditions = {};
            if (frequency) {
                whereConditions['$checklist.frequency$'] = frequency;
            }
            if (userId) {
                whereConditions.user_id = userId;
            }
            if (startDate && endDate) {
                whereConditions.completed_at = {
                    [Op.between]: [
                        moment(startDate)?.startOf('day')?.toDate(),
                        moment(endDate)?.endOf('day')?.toDate()
                    ]
                };
            }
            const { count, rows } = await ChecklistResponse.findAndCountAll({
                where: whereConditions,
                include: [
                    {
                        model: Checklist,
                        as: 'checklist',
                        attributes: ['id', 'name', 'frequency'],
                        ...(frequency ? { where: { frequency } } : {})
                    },
                    {
                        model: User,
                        as: 'user',
                        attributes: ['id', 'name', 'email']
                    }
                ],
                distinct: true,
                order: [['completed_at', 'DESC']],
                limit: parseInt(pageSize),
                offset: parseInt(offset)
            });

            const users = rows.map((row, index) => ({
                id: index,
                name: row?.user?.name,
                email: row?.user?.email,
                response_id: row?.id,
                checklist_id: row?.checklist.id,
                checklist_name: row?.checklist.name,
                last_checklist_date: row?.completed_at
            }));

            return {
                users,
                total: count,
                page: parseInt(page),
                pageSize: parseInt(pageSize)
            };
        } catch (error) {
            console.error('Error fetching users with checklists:', error);
            throw new AppError("Error fetching users with checklists", 500);
        }
    }
};