const AppError = require("../utils/appError");
const { Op } = require("sequelize");
const { User, UserRole } = require("../config/database");
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { JWT_SECRET, JWT_ACCESS_EXPIRES_IN, JWT_REFRESH_SECRET, JWT_REFRESH_EXPIRES_IN, ses, sendVerificationEmail, generateVerificationCode, VERIFICATION_CODE_EXPIRY_MINUTES } = require("../utils/utils");

module.exports = {
  register: async (body) => {
    try {
      const { email, password, name } = body
      const existingUser = await User.findOne({ where: { email } });
      if (existingUser) {
        throw new AppError('Email already in use', 400);
      }
      const defaultRole = await UserRole.findOne({ where: { name: 'Employee' } });
      if (!defaultRole) {
        throw new AppError("Default role not found", 404);
      }
      const hashedPassword = await bcrypt.hash(password, 12);
      const user = await User.create({
        name: name || '',
        email,
        password: hashedPassword,
        role_id: defaultRole?.id,
      });
      const accessToken = jwt.sign(
        { userId: user.id, email: user.email, userRole: defaultRole?.name },
        JWT_SECRET,
        { expiresIn: JWT_ACCESS_EXPIRES_IN }
      );

      const refreshToken = jwt.sign(
        { userId: user?.id, email: user?.email, userRole: defaultRole?.name },
        JWT_REFRESH_SECRET,
        { expiresIn: JWT_REFRESH_EXPIRES_IN }
      );

      return {
        message: 'User created successfully',
        userId: user?.id,
        accessToken,
        refreshToken,
        role: defaultRole?.name,
      };
    } catch (error) {
      console.error('Signup error:', error);
      throw new AppError("Error while creating user", 500);
    }
  },

  signin: async (payload) => {
    try {
      const { email, password } = payload
      const user = await User.findOne({
        where: { email },
        attributes: ['id', 'name', 'email', 'password', "is_verified"],
        include: [{
          model: UserRole,
          as: 'role',
          attributes: ['id', 'name']
        }]
      });

      if (!user || !user?.role || !user?.is_verified) {
        throw new AppError('Authentication failed', 400);
      }
      const isEqual = await bcrypt.compare(password, user?.password);
      if (!isEqual) {
        throw new AppError('Authentication failed', 400)
      }

      const accessToken = jwt.sign(
        { userId: user?.id, email: user?.email, userRole: user?.role?.name },
        JWT_SECRET,
        { expiresIn: JWT_ACCESS_EXPIRES_IN }
      );

      const refreshToken = jwt.sign(
        { userId: user?.id, email: user?.email, userRole: user?.role?.name },
        JWT_REFRESH_SECRET,
        { expiresIn: JWT_REFRESH_EXPIRES_IN }
      );

      return {
        message: 'Authentication successful',
        user: user?.id,
        accessToken,
        refreshToken,
        role: user?.role?.name,
      };
    }
    catch (error) {
      const { message, statusCode } = error
      console.log('Signin error:', error, message, statusCode);
      throw new AppError(message, statusCode);
    }
  },
  
  refresh: async (payload) => {
    try {
      const { refreshToken } = payload
      const decoded = jwt.verify(refreshToken, JWT_REFRESH_SECRET);
      const user = await User.findOne({
        where: { id: decoded?.userId },
        attributes: ['id', 'name', 'email', 'password'],
        include: [{
          model: UserRole,
          as: 'role',
          attributes: ['id', 'name']
        }]
      });
      if (!user) {
        throw new AppError('Invalid refresh token', 401);
      }
      const newAccessToken = jwt.sign(
        { userId: user?.id, email: user?.email, userRole: user?.role?.name },
        JWT_SECRET,
        { expiresIn: JWT_ACCESS_EXPIRES_IN }
      );
      const newRefreshToken = jwt.sign(
        { userId: user?.id, email: user?.email, userRole: user?.role?.name },
        JWT_REFRESH_SECRET,
        { expiresIn: JWT_REFRESH_EXPIRES_IN }
      );

      return {
        accessToken: newAccessToken,
        newRefreshToken
      }
    } catch (error) {
      console.error('Refresh error:', error);
      throw new AppError("Error while refresh token", 500);
    }
  },

  requestPassword: async (payload) => {
    try {
      const { email } = payload
      const user = await User.findOne({ where: { email } });
      if (!user) {
        throw new AppError('Invalid email or user not found', 404)
      }
      const resetToken = crypto.randomBytes(32).toString('hex');
      const resetTokenExpiry = Date.now() + 3600000;

      await user.update({
        reset_token: resetToken,
        reset_token_expiry: resetTokenExpiry,
      });
      const resetUrl = `${process.env.FRONTEND_URL}/reset-password/${resetToken}`;

      const params = {
        Destination: {
          ToAddresses: [email]
        },
        Message: {
          Body: {
            Html: {
              Charset: "UTF-8",
              Data: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                  <h2 style="color: #213654;">Password Reset Request</h2>
                  <p>You requested a password reset for your Bitcoin Mining account.</p>
                  <p>Click the button below to reset your password:</p>
                  <div style="margin: 20px 0;">
                    <a href="${resetUrl}" style="background-color: #eb8511; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">
                      Reset Password
                    </a>
                  </div>
                  <p>This link will expire in 1 hour. If you didn't request this, please ignore this email.</p>
                  <p style="color: #666; font-size: 12px; margin-top: 30px;">
                    © ${new Date().getFullYear()} Bitcoin Mining. All rights reserved.
                  </p>
                </div>
              `
            },
            Text: {
              Charset: "UTF-8",
              Data: `You requested a password reset. Please use the following link to reset your password: ${resetUrl}\n\nThis link expires in 1 hour.`
            }
          },
          Subject: {
            Charset: "UTF-8",
            Data: "Password Reset Request"
          }
        },
        Source: `Bitcoin Mining <${process.env.SES_FROM_EMAIL}>`,
      };

      await ses.sendEmail(params).promise();

      return { message: 'If an account exists, a reset link has been sent' };
    } catch (error) {
      console.error("Error sending password reset email:", error);
      throw new AppError("Error sending email", 500);
    }
  },

  reset: async (payload) => {
    try {
      const { token, newPassword } = payload
      const user = await User.findOne({
        where: {
          reset_token: token,
          reset_token_expiry: { [Op.gt]: Date.now() }
        }
      });

      if (!user) {
        throw new AppError('Invalid or expired reset token', 404);
      }
      const hashedPassword = await bcrypt.hash(newPassword, 12);
      await user.update({
        password: hashedPassword,
        reset_token: null,
        reset_token_expiry: null,
      });

      return { message: 'Password reset successfully' };
    } catch (error) {
      console.error('Error  reset password:', error);
      throw new AppError("Error while resetting password", 500);
    }
  },

  getUser: async (id) => {
    try {
      const user = await User.findByPk(id, {
        attributes: { exclude: ['password'] }
      });
      if (!user) {
        throw new AppError('User not found', 404);
      }
      return { user }
    } catch (error) {
      console.error('Error getting user info', error);
      throw new AppError("Error getting user info ", 500);
    }
  },

  getUsers: async (req) => {
    try {
      if (req?.userRole !== 'Admin') {
        throw new AppError('Not authorized', 403);
      }

      const { page = 1, pageSize = 10 } = req.query;
      const offset = (page - 1) * pageSize;
      const { count, rows: users } = await User.findAndCountAll({
        attributes: { exclude: ['password'] },
        order: [['createdAt', 'DESC']],
        limit: parseInt(pageSize),
        offset: parseInt(offset)
      });
      return { users, total: count, page: parseInt(page), pageSize: parseInt(pageSize) }
    } catch (error) {
      console.error('Error getting user lists:', error);
      throw new AppError("Error getting user list", 500);
    }
  },

  updateUser: async (req) => {
    try {
      const { id } = req.params;
      const { roleId } = req.body;

      const existingUser = await UserRole.findOne({ where: { id: roleId } });
      if (!['Admin', 'Employee'].includes(existingUser?.name)) {
        throw new AppError('Invalid role', 400);
      }

      const user = await User.findByPk(id);
      if (!user) {
        throw new AppError('User not found', 404)
      }
      user.role_id = roleId;
      await user?.save();
      return { user }
    } catch (error) {
      console.error('Error updating', error);
      throw new AppError("Error while updating user", 500);
    }
  },

  validate: async (id) => {
    try {
      const user = await User.findByPk(id, {
        include: [{
          model: UserRole,
          as: 'role',
          attributes: ['name']
        }]
      });

      if (!user) {
        throw new AppError('User not found', 404);
      }
      return { user }
    } catch (error) {
      console.error('Error validating user', error);
      throw new AppError("Error while updating user", 500);
    }
  },

  initiateSignup: async (body) => {
    try {
      const { email, name, password } = body;
      const existingVerifiedUser = await User.findOne({
        where: {
          email,
          is_verified: true
        }
      });

      if (existingVerifiedUser) {
        throw new AppError('Email already in use', 400);
      }
      const existingUnverifiedUser = await User?.findOne({
        where: {
          email,
          is_verified: false
        }
      });

      const verificationCode = generateVerificationCode();
      const verificationExpiry = Date.now() + (VERIFICATION_CODE_EXPIRY_MINUTES * 60 * 1000);

      if (existingUnverifiedUser) {
        await existingUnverifiedUser.update({
          name,
          verification_code: verificationCode,
          verification_expiry: verificationExpiry
        });
      } else {
        const hashedPassword = await bcrypt.hash(password, 12);
        const defaultRole = await UserRole.findOne({ where: { name: 'Employee' } });
        if (!defaultRole) {
          throw new AppError("Default role not found", 404);
        }

        await User.create({
          name,
          email,
          password: hashedPassword,
          verification_code: verificationCode,
          verification_expiry: verificationExpiry,
          role_id: defaultRole.id,
          is_verified: false
        });
      }
      await sendVerificationEmail(email, verificationCode);

      return {
        message: 'Verification code sent to your email',
        email
      };
    } catch (error) {
      console.error('Signup initiation error:', error);
      throw new AppError(error.message || "Error initiating signup", 500);
    }
  },

  verifyAndCompleteSignup: async (payload) => {
    try {
      const { email, code } = payload;
      const user = await User.scope('withVerification').findOne({
        where: {
          email,
          is_verified: false,
          verification_code: code,
          verification_expiry: { [Op.gt]: Date.now() }
        },
        attributes: ['id', 'name', 'email', 'password'],
        include: [{
          model: UserRole,
          as: 'role',
          attributes: ['id', 'name',]
        }]
      });

      if (!user) {
        throw new AppError('Invalid or expired verification code', 400);
      }

      await user.update({
        is_verified: true,
        verification_code: null,
        verification_expiry: null
      });
      const accessToken = jwt.sign(
        { userId: user?.id, email: user?.email, userRole: user?.role?.name },
        JWT_SECRET,
        { expiresIn: JWT_ACCESS_EXPIRES_IN }
      );

      const refreshToken = jwt.sign(
        { userId: user?.id, email: user?.email, userRole: user?.role?.name },
        JWT_REFRESH_SECRET,
        { expiresIn: JWT_REFRESH_EXPIRES_IN }
      );

      return {
        message: 'Registration completed successfully',
        userId: user?.id,
        accessToken,
        refreshToken,
        role: user?.role?.name
      };
    } catch (error) {
      console.error('Verification error:', error);
      throw new AppError(error?.message || "Error completing registration", 500);
    }
  },

  resendVerificationCode: async (payload) => {
    try {
      const { email } = payload;

      const user = await User?.findOne({
        where: {
          email,
          is_verified: false
        }
      });

      if (!user) {
        throw new AppError('No pending registration found for this email', 404);
      }

      const verificationCode = generateVerificationCode();
      const verificationExpiry = Date.now() + (VERIFICATION_CODE_EXPIRY_MINUTES * 60 * 1000);

      await user.update({
        verification_code: verificationCode,
        verification_expiry: verificationExpiry
      });

      await sendVerificationEmail(email, verificationCode);

      return {
        message: 'New verification code sent to your email',
        email
      };
    } catch (error) {
      console.error('Resend verification error:', error);
      throw new AppError(error.message || "Error resending verification code", 500);
    }
  },

  getAllUsersForAdmin: async () => {
    try {
      const users = await User.findAll({
        attributes: ['id', 'name', 'email'],
        order: [['name', 'ASC']]
      });
      return { users }
    } catch (error) {
      console.error('Resend verification error:', error);
      throw new AppError(error.message || "Error fetching users", 500);
    }
  }
};
