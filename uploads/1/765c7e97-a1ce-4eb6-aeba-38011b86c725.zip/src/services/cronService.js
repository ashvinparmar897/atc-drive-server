const cron = require('node-cron');
const moment = require('moment-timezone');
const { Op } = require('sequelize');
const {
  getAndClearAccumulatedData,
  fetchLogsAndPoolsData,
} = require("./rabbitMQService");
const { getCurrentTime, extractMetrics, FREQUENCY_REPORT_HOUR, DAILY_REPORT_HOUR, TIMEZONE } = require("../utils/utils");
const {
  getTotalPowerSum,
  latestDeviceData,
  getDevicePowerConsumption,
} = require("./powerService");
const { loginToGasum, sendTimeseriesData } = require("./gasumService");

const AppError = require('../utils/appError');
const {
  ContainerHourlyPower,
  ContainerManualEntry,
  CronSchedule, Container
} = require('../config/database');
const { GASUM_PER_MINUTE_TIME_SERIES_ID, GASUM_SCHEDULED_TIME_SERIES_ID } = require('../constants/constants');
const { syncMinerDataFromRedis } = require('../processors/dataStorageService');


function formatDataForAPI() {
  return [
    {
      status: "ENTERED",
      time: getCurrentTime(),
      validate: false,
      value: Number(getTotalPowerSum()?.toFixed(2)),
    },
  ];
}

async function processContainerData(content, power) {
  if (!content || !content?.deviceName || !content?.cruxData) return;

  try {
    const containerName = content?.deviceName;
    const metrics = extractMetrics(content?.cruxData);

    if (content?.totalPower) {
      metrics.total_power = parseFloat(content?.totalPower);
    }
    await Container.upsert({
      container_name: containerName,
      total_power: power,
      ...metrics,
      updated_at: new Date(),
    });
  } catch (error) {
    console.error(`Error processing ${"containerName"}:`, error);
  }
}

async function runScheduledJob() {
  try {
    const formattedData = formatDataForAPI();
    // console.log("Power data to send:", formattedData);
    const accessToken = await loginToGasum();
    if (!accessToken) {
      console.log("Failed to get access token. Skipping this run.");
      return;
    }
    // console.log('accessToken --> ', accessToken);
    sendTimeseriesData(accessToken, formattedData, GASUM_PER_MINUTE_TIME_SERIES_ID).catch((e) => {
      console.error("Error sending timeseries data to Gasum API:", e);
    });
    const deviceConsumptions = getDevicePowerConsumption();
    const devicesToProcess = getAndClearAccumulatedData();
    await Promise.all(
      Array.from(devicesToProcess.values()).map((element) =>
        processContainerData(element, deviceConsumptions[element?.deviceName])
      )
    );

    updateDailyPower();
  } catch (error) {
    console.error("Error in scheduled job:", error);
  }
}

async function updateDailyPower() {
  const today = moment().startOf('day');
  const currentPower = Number(getTotalPowerSum()?.toFixed(2));
  try {
    const [dailyRecord, created] = await ContainerHourlyPower.findOrCreate({
      where: { date: today.toDate(), },
      defaults: { max_power: currentPower }
    });

    if (!created && currentPower > dailyRecord?.max_power) {
      await dailyRecord.update({ max_power: currentPower });
    }

    return { dailyRecord };
  } catch (error) {
    console.error('Error updating daily power:', error);
    throw error;
  } finally {
    latestDeviceData.clear();
  }
}

async function runDailyCronJob() {
  try {
    const schedule = await CronSchedule?.findOne();
    if (!schedule) {
      console.log('No cron schedule found');
      return;
    }

    const lastRun = schedule?.lastRun ? moment(schedule?.lastRun).tz(TIMEZONE) : null;
    if (lastRun) {
      const daysSinceLastRun = moment().tz(TIMEZONE).diff(lastRun, 'days')
      if (daysSinceLastRun < 7) {
        console.log(`Frequency is every ${schedule?.frequencyDays} days`);
        return;
      }
    }
    const today = moment(new Date());
    const endDate = moment(today).add(schedule?.frequencyDays - 1, 'days').endOf('day');
    const yesterday = moment(today).subtract(1, 'day').startOf('day');

    const yesterdayPower = await ContainerHourlyPower.findOne({
      where: {
        date: {
          [Op.between]: [
            yesterday.startOf('day').toDate(),
            yesterday.endOf('day').toDate()
          ]
        }
      },
      order: [['max_power', 'DESC']]
    });
    const fallbackValue = yesterdayPower ? yesterdayPower?.max_power > 70 ? 70 : yesterdayPower?.max_power : 0;
    const manualEntries = await ContainerManualEntry.findAll({
      where: {
        start_time: {
          [Op.between]: [today?.startOf('day').toDate(), endDate?.endOf('day').toDate()]
        }
      }
    });

    const allData = [];
    for (let day = 0; day < schedule?.frequencyDays; day++) {
      const currentDate = today.clone().add(day, 'days');

      for (let hour = 0; hour < 24; hour++) {
        const slotStart = currentDate?.clone().hour(hour).minute(0).second(0);
        const slotEnd = slotStart?.clone().add(59, 'minutes');

        const manualEntry = manualEntries.find(entry => {
          const entryStart = moment(entry.start_time);
          const entryEnd = moment(entry.end_time);
          return (
            (slotStart?.isSameOrAfter(entryStart) && slotStart?.isBefore(entryEnd)) ||
            (slotEnd?.isAfter(entryStart) && slotEnd?.isSameOrBefore(entryEnd)) ||
            (slotStart?.isSameOrBefore(entryStart) && slotEnd?.isSameOrAfter(entryEnd))
          );
        });

        allData.push({
          time: slotStart?.format('YYYY-MM-DDTHH:mm:ss[Z]'),
          value: manualEntry ? manualEntry?.power_value > 70 ? 70 : manualEntry?.power_value : fallbackValue,
          status: 'Entered',
          validate: false,
          unit: "MWh"
        });
      }
    }

    // Send to Gasum
    const accessToken = await loginToGasum();
    if (accessToken) {
      await sendTimeseriesData(accessToken, allData, GASUM_SCHEDULED_TIME_SERIES_ID);

      await schedule?.update({ lastRun: new Date() });

      console.log(`Sent ${allData.length} entries to Gasum`);
    }
  } catch (error) {
    console.error('Error in daily cron job:', error);
  }
}
async function runRealtimeCronJob() {
  try {
    const today = moment(new Date());
    const tomorrow = moment(today)?.add(1, 'day')?.startOf('day');

    const yesterday = moment(today)?.subtract(1, 'day')?.startOf('day');

    const yesterdayPower = await ContainerHourlyPower.findOne({
      where: {
        date: {
          [Op.between]: [
            yesterday.startOf('day').toDate(),
            yesterday.endOf('day').toDate()
          ]
        }
      },
      order: [['max_power', 'DESC']]
    });

    const fallbackValue = yesterdayPower ? yesterdayPower?.max_power > 70 ? 70 : yesterdayPower?.max_power : 0;

    const manualEntries = await ContainerManualEntry.findAll({
      where: {
        start_time: {
          [Op.between]: [tomorrow?.startOf('day')?.toDate(), tomorrow?.endOf('day')?.toDate()]
        }
      }
    });

    const hourlyData = [];
    for (let hour = 0; hour < 24; hour++) {
      const slotStart = tomorrow?.clone()?.hour(hour)?.minute(0).second(0);
      const slotEnd = slotStart?.clone().add(59, 'minutes');

      const manualEntry = manualEntries.find(entry => {
        const entryStart = moment(entry?.start_time);
        const entryEnd = moment(entry?.end_time);
        return (
          (slotStart?.isSameOrAfter(entryStart) && slotStart?.isBefore(entryEnd)) ||
          (slotEnd?.isAfter(entryStart) && slotEnd?.isSameOrBefore(entryEnd)) ||
          (slotStart?.isSameOrBefore(entryStart) && slotEnd?.isSameOrAfter(entryEnd))
        );
      });
      hourlyData.push({
        time: slotStart.format('YYYY-MM-DDTHH:mm:ss[Z]'),
        value: manualEntry ? manualEntry?.power_value > 70 ? 70 : manualEntry?.power_value : fallbackValue,
        status: 'Entered',
        validate: false,
        unit: "MWh"
      });
    }


    const accessToken = await loginToGasum();
    if (accessToken) {
      await sendTimeseriesData(accessToken, hourlyData, GASUM_SCHEDULED_TIME_SERIES_ID);
      // console.log(`Sent ${hourlyData.length} realtime entries to Gasum`);

      await ContainerManualEntry.destroy({
        where: {
          start_time: {
            [Op.lt]: today?.startOf('day')?.toDate()
          }
        }
      });

      await ContainerHourlyPower.destroy({
        where: {
          date: {
            [Op.lt]: today?.clone()?.subtract(1, 'day')?.startOf('day')?.toDate()
          }
        }
      });

      const todayEntry = await ContainerHourlyPower?.findOne({
        where: {
          date: {
            [Op.eq]: today?.clone()?.subtract(1, 'day')?.toDate()
          }
        }
      });

      if (todayEntry) {
        todayEntry.is_sent = true;
        todayEntry.sent_at = moment()?.toISOString();

        await todayEntry?.save()
      }
    }


  } catch (error) {
    console.error('Error in realtime cron job:', error);
  }
}

const getCronSchedule = async () => {
  try {
    let schedule = await CronSchedule?.findOne();
    if (!schedule) {
      schedule = await CronSchedule?.create({ frequencyDays: 1 });
    }
    return { schedule }
  } catch (error) {
    console.error('Error getting cron schedule:', error);
    throw new AppError("Failed to Create Cron Schedule", 500)
  }
};

const updateCronSchedule = async (frequencyDays) => {
  try {
    let schedule = await CronSchedule?.findOne();
    if (!schedule) {
      schedule = await CronSchedule?.create({ frequencyDays });
    } else {
      const cutoffDate = moment().add(frequencyDays, 'days').endOf('day').toDate();
      await ContainerManualEntry.destroy({
        where: {
          start_time: {
            [Op.gt]: cutoffDate
          }
        }
      });
      schedule = await schedule?.update({ frequencyDays });
    }

    return { schedule };
  } catch (error) {
    console.error('Error updating cron schedule:', error);
    throw new AppError("Failed to update Cron Schedule", 500);
  }
};

function scheduleJobs() {
  fetchLogsAndPoolsData();
  // cron.schedule(`0 ${FREQUENCY_REPORT_HOUR} * * *`, () => {
  //   runDailyCronJob();
  // }, {
  //   timezone: TIMEZONE,
  // });

  // cron.schedule(`0 ${DAILY_REPORT_HOUR} * * *`, () => {
  //   runRealtimeCronJob();
  // }, {
  //   timezone: TIMEZONE,
  // });
  cron.schedule("0 * * * * *", runScheduledJob);
  cron.schedule("*/5 * * * * ", syncMinerDataFromRedis);
}



module.exports = {
  scheduleJobs,
  updateDailyPower,
  getCronSchedule,
  updateCronSchedule
};