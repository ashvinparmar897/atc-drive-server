const axios = require('axios');
const AppError = require("../utils/appError");
const { COINGECKO_BITCOIN_API_URL } = require('../constants/constants');

const getBitcoinPrice = async () => {
  try {
    const response = await axios.get(COINGECKO_BITCOIN_API_URL, {
      params: {
        ids: 'bitcoin',
        vs_currencies: 'usd',
        include_24hr_change: true,
        include_24hr_vol: true,
        include_market_cap: true
      }
    });

    const bitcoinData = response?.data?.bitcoin;
    
    return {
      price: bitcoinData?.usd,
      price_change_24h: bitcoinData?.usd_24h_change,
      volume_24h: bitcoinData?.usd_24h_vol,
      market_cap: bitcoinData?.usd_market_cap,
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    console.error('Error fetching Bitcoin price:', error.message);
    throw new AppError('Failed to fetch Bitcoin price data', 500);
  }
};

module.exports = {
  getBitcoinPrice,
}; 