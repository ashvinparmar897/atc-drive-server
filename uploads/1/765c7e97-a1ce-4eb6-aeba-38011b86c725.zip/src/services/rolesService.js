const AppError = require("../utils/appError");
const { UserRole } = require("../config/database");

module.exports = {
  getRolesList: async (req) => {
    try {

      if (req?.userRole !== 'Admin') {
        throw new AppError('Not authorized', 403);
      }
      const roles = await UserRole?.findAll();
      if (!roles || !roles?.length) {
        throw new AppError("Roles not found", 500);
      }
      return {
        roles,
      };
    } catch (error) {
      console.log(error, "error==");
      throw new AppError("Error while fetching role details", 500);
    }
  },
};
