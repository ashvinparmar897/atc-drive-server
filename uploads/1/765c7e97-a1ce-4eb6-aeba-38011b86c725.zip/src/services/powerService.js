const { POWER_KEYS } = require("../utils/utils");

const latestDeviceData = new Map();

function calculatePowerSum(cruxData = []) {
  return POWER_KEYS.reduce((sum, key) => {
    const item = cruxData?.find((d) => d?.name === key);
    return sum + (parseFloat(item?.value) || 0);
  }, 0);
}

function getTotalPowerSum() {

  // Array.from(latestDeviceData.values()).reduce(
  //   (total, data) => total + calculatePowerSum(data?.cruxData || []),
  //   0
  // ) / 1000

  let total = 0;
  latestDeviceData.forEach((container) => {
    if (container?.totalPower) {
      total += parseFloat(container?.totalPower);
    }
  });
  return total / 1000;

}

function getDevicePowerConsumption() {
  // const result = {};
  // Array.from(latestDeviceData.entries()).forEach(([deviceName, data]) => {
  //   result[deviceName] = calculatePowerSum(data?.cruxData || []);
  // });
  // return result;
  const consumptions = {};
  latestDeviceData.forEach((container, deviceName) => {
    consumptions[deviceName] = container?.totalPower
      ? parseFloat(container?.totalPower)
      : 0;
  });
  return consumptions;
}

module.exports = {
  latestDeviceData,
  calculatePowerSum,
  getTotalPowerSum,
  getDevicePowerConsumption,
};
