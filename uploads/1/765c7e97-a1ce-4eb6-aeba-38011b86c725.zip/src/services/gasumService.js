const AppError = require("../utils/appError");
const {
  GASUM_API_URL,
  GASUM_LOGIN_SUBSCRIPTION_KEY,
  GASUM_LOGIN_PASSWORD,
  GASUM_LOGIN_USERNAME,
} = require("../constants/constants");
const { default: axios } = require("axios");

const headers = {
  // Accept: "application/json",
  "Content-Type": "application/json",
  "Ocp-Apim-Subscription-Key": GASUM_LOGIN_SUBSCRIPTION_KEY,
};

const grant_type = new URLSearchParams({
  grant_type: "password",
  username: GASUM_LOGIN_USERNAME,
  password: GASUM_LOGIN_PASSWORD,
});

module.exports = {
  loginToGasum: async () => {
    try {
      const response = await axios.post(GASUM_API_URL + "token", grant_type, {
        headers,
      });

      const accessToken = response.data.access_token;
      return accessToken;
    } catch (error) {
      console.error(
        "Error logging into Gasum API:",
        error.response?.data || error.message
      );
      return new AppError("Error logging into Gasum API:", 400);
    }
  },

  sendTimeseriesData: async (accessToken, payload, timeSeriesID) => {
    try {
      const newHeaders = { ...headers, Authorization: `Bearer ${accessToken}` };

      const response = await axios.put(
        GASUM_API_URL + `api/timeseries/${timeSeriesID}/values`,
        payload,
        {
          headers: newHeaders,
        }
      );
      // console.log("DATA sent to GASUM", response?.data)
      return response.data;
    } catch (error) {
      console.error(
        "Error sending timeseries data to Gasum API:",
        error.response?.data || error.message
      );
      return new AppError("Error sending timeseries data to Gasum API:", 400);
    }
  },
};
