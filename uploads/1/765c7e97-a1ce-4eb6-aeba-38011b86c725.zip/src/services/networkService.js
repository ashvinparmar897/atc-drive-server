const axios = require("axios");
const {
  filterDataAccordingToCurrentTimeZone,
  getConvertedDataInEUR,
} = require("../utils/utils");
const BigNumber = require("bignumber.js");
const AppError = require("../utils/appError");
const {
  USD_CURRENCY,
  EUR_CURRENCY,
  BINANCE_BITCOIN_API_URL,
  HASHRATE_API_KEY,
  HASHRATE_API_URL,
  MINING_POOL_FEES,
} = require("../constants/constants");

const headers = {
  "X-Hi-Api-Key": `${HASHRATE_API_KEY}`,
  "Content-Type": "application/json",
};

module.exports = {
  getProfit: async (query) => {
    try {
      const {
        petaHashPerDay,
        electricityConsumption,
        price,
        noOfDays,
        currency = USD_CURRENCY,
      } = query;

      // Fetch Current Hash Price in USD
      const currentHashPriceResponse = await axios.get(
        `${HASHRATE_API_URL}hashprice?currency=USD&hashunit=PHS&span=1D`,
        { headers }
      );

      if (!currentHashPriceResponse?.data?.data) {
        throw new AppError("Error while fetching current hashprice", 400);
      }

      const currentHashPriceData = currentHashPriceResponse.data.data;

      const getCurrentHashPriceInUSD =
        filterDataAccordingToCurrentTimeZone(currentHashPriceData);

      const currentHashPrice = getCurrentHashPriceInUSD?.price;

      const totalRevenue = currentHashPrice * petaHashPerDay;

      const totalConsumption = electricityConsumption * price * 24; // Electricity cost per day

      let totalExpense = totalConsumption;

      let totalProfit = totalRevenue - totalExpense;
      let finalProfit = totalProfit;

      let convertedHashPrice = currentHashPrice;

      // If EUR is requested, fetch conversion rate and adjust values
      if (currency === EUR_CURRENCY) {
        const { conversionRate } = await getConvertedDataInEUR();
        if (!conversionRate) {
          throw new AppError("Error while converting currencies", 400);
        }

        finalProfit *= conversionRate;
        convertedHashPrice *= conversionRate;
      }

      return {
        profit: Number(finalProfit * noOfDays).toFixed(2),
        hashPrice: Number(convertedHashPrice).toFixed(2),
      };
    } catch (error) {
      console.error(error, "error==");
      throw new AppError("Error while fetching profit", 500);
    }
  },

  getStrikePrice: async (query) => {
    const { minerType, currency } = query;
    try {
      const btcPriceResponse = await axios.get(BINANCE_BITCOIN_API_URL);
      const bitcoinPrice = parseFloat(btcPriceResponse?.data?.price);

      if (!btcPriceResponse?.data?.price) {
        throw new AppError("Failed to fetch Bitcoin price from Binance", 500);
      }

      // Fetch model info (hashrate in TH/s, power in watts through ASIC models)
      const asicModelsResponse = await axios.get(
        HASHRATE_API_URL + "asic/models",
        { headers }
      );

      const minersData = asicModelsResponse?.data;

      // Fetch our model (currently working for S21)
      const minerInfo = minersData?.data?.filter(
        (element) => element.model == minerType
      );

      if (!minerInfo || minerInfo.length === 0) {
        throw new AppError("Miner not found", 404);
      }

      // Fetch network hashrate for BTC
      const networkHashRateResponse = await axios.get(
        HASHRATE_API_URL + "network/hashrate?sma=3D&span=1D",
        { headers }
      );
      const networkHashRateData = networkHashRateResponse?.data?.data;

      if (!networkHashRateData?.length) {
        throw new AppError("Network hashrate not found", 404);
      }

      // Get the hashrate according to the current timezone
      const getCurrentNetworkHashrate =
        filterDataAccordingToCurrentTimeZone(networkHashRateData);

      // Fetch block reward for BTC
      const blockRewardResponse = await axios.get(
        HASHRATE_API_URL + "network/block-reward?span=1D",
        { headers }
      );
      const blockRewardData = blockRewardResponse?.data?.data;

      if (!blockRewardData?.length) {
        throw new AppError("Info not found for block reward", 404);
      }

      //Get the current value for block reward according to cureent timezone
      const currentBlockReward =
        filterDataAccordingToCurrentTimeZone(blockRewardData);

      const minerHashrate = minerInfo[0]?.hashrate;

      const powerConsumptionWatt = minerInfo[0]?.power;

      const networkHashrate = getCurrentNetworkHashrate?.hashrate;

      const blockReward = currentBlockReward?.blockReward;

      const networkHashrateEH = new BigNumber(networkHashrate?.toFixed(15)); // in EH/s
      const networkHashrateTH = networkHashrateEH?.times(1e6); // Convert EH/s to TH/s (1 EH = 1,000,000 TH)
      const blockReward1 = new BigNumber(blockReward); // in BTC
      const miningPoolFees = new BigNumber(MINING_POOL_FEES); // 2%

      // Miner info
      const minerHashrateTHBig = new BigNumber(minerHashrate); // in TH/s
      const minerPowerConsumptionKWBig = new BigNumber(
        powerConsumptionWatt
      ).dividedBy(1000); // Convert W to kW

      // Calculate miner's share of the network hashrate
      const minerShare = minerHashrateTHBig?.dividedBy(networkHashrateTH);

      // Calculate expected block reward per hour
      const blocksPerHour = new BigNumber(6);
      const expectedBlockRewardPerHour = blockReward1
        .times(minerShare)
        .times(blocksPerHour);

      // Adjust for mining pool fees
      // const expectedRewardAfterFees = expectedBlockRewardPerHour?.times(
      //   new BigNumber(1).minus(miningPoolFees)
      // );
      const expectedRewardAfterFees = expectedBlockRewardPerHour.times(
        new BigNumber(1).minus(new BigNumber(miningPoolFees).dividedBy(100))
      );

      // Calculate threshold electricity price (convert from USD/kWh to USD/MWh by multiplying by 1000)
      const strikePrice = expectedRewardAfterFees
        .times(bitcoinPrice)
        .dividedBy(minerPowerConsumptionKWBig)
        .times(1000);

      let finalValue = strikePrice;

      if (currency === EUR_CURRENCY) {
        const { conversionRate } = await getConvertedDataInEUR();
        if (!conversionRate) {
          throw new AppError("Error while converting currencies", 400);
        }
        finalValue *= conversionRate;
      }

      return {
        strikePrice: Number(finalValue).toFixed(2),
      };
    } catch (error) {
      console.log(error, "error==");
      throw new AppError("Error while fetching strike price", 500);
    }
  },
};
