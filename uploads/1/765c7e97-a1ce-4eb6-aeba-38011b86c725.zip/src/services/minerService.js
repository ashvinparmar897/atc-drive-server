const AppError = require("../utils/appError");
const { redisClientRead } = require("../config");

module.exports = {
  getMinerDetailsById: async (ip) => {
    try {
      if (!redisClientRead.isOpen) await redisClientRead.connect();
      const keys = await redisClientRead.keys("miner:*");
      for (const key of keys) {
        const data = await redisClientRead.hGetAll(key);
        if (data?.ip === ip) {
          const miner = {
            id: null,
            mac_address: data?.mac,
            ip: data?.ip,
            type: data?.type,
            model: data?.model,
            version: data?.version,
            compile_time: data?.compile_time,
            miner_id: data?.miner_id,
            agent_id: data?.agent_id,
            status: data?.status,
            created_at: null,
            updated_at: new Date(Number(data?.last_updated)),
          };

          const stats = {
            id: null,
            miner_mac: data?.mac,
            hashrate_current: parseFloat(data?.hashrate_current || "0"),
            hashrate_average: parseFloat(data?.hashrate_average || "0"),
            hashrate_30m: parseFloat(data?.hashrate_30m || "0"),
            hashrates: JSON.parse(data?.hashrates || "[]"),
            temperature_values: JSON.parse(data?.temperature_values || "[]"),
            temperature_max: parseFloat(data?.temperature_max || "0"),
            fan_speeds: JSON.parse(data?.fan_speeds || "[]"),
            frequencies: JSON.parse(data?.frequencies || "[]"),
            frequency_avg: parseFloat(data?.frequency_avg || "0"),
            active_chains: JSON.parse(data?.active_chains || "[]"),
            active_chains_info: JSON.parse(data?.active_chains_info || "{}"),
            created_at: null,
            updated_at: new Date(Number(data?.last_updated)),
          };

          const pools = (JSON.parse(data?.pools || "[]") || [])?.map(pool => ({
            id: null,
            url: pool?.url,
            worker: pool?.worker,
            status: pool?.status,
            priority: pool?.priority,
            accepted: pool?.accepted,
            rejected: pool?.rejected,
            miner_mac: pool?.miner_mac,
            created_at: null,
            updated_at: new Date(Number(data?.last_updated)),
          }));
          return { miner, stats, pools };
        }
      }
      throw new AppError("Miner not found", 404);
    } catch (error) {
      console.error("Error in getMinerDetailsById (Redis):", error);
      throw new AppError("Error while fetching miner details", 500);
    }
  },
};
