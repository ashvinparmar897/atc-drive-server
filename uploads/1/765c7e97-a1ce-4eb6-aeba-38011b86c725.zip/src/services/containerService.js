const AppError = require("../utils/appError");
const { Container, ContainerManualEntry, AlertConfig, sequelize } = require("../config/database");
const { Op } = require("sequelize");
const moment = require('moment-timezone');
const { TIMEZONE } = require("../utils/utils");

module.exports = {
  getContainerDetails: async () => {
    try {
      const containers = await Container?.findAll();
      if (!containers || !containers?.length) {
        throw new AppError("Conatiners not found", 500);
      }

      return {
        containers,
      };
    } catch (error) {
      console.log(error, "error==");
      throw new AppError("Error while fetching miner details", 500);
    }
  },

  getContainerNames : async () => {
    try {
       const containers = await Container.findAll({
      attributes: ["container_name"],
      order: [
        [sequelize.literal("CAST(SUBSTRING(container_name FROM '[0-9]+') AS INTEGER)"), "ASC"]
      ],
    });
    return {
      containerNames : containers?.map((c) => c?.container_name)
    }
    } catch (error) {
      console.error('Error fetching container names', error);
      throw error;
    }
  },

  getPowerUsageSinceMidnightTotal : async () => {
    try {
      const records = await Container.findAll();
      const energySum = records.reduce((sum, row) => {
        const power = row.total_power ?? 0;
        return sum + Number(power);
      }, 0);
      const now = moment.tz(TIMEZONE); 
      const midnight = now.clone().startOf("day");

      const hoursSinceMidnight = Math.round(moment.duration(now.diff(midnight)).asHours());

      const totalConsumption = energySum * hoursSinceMidnight;

      return {  
        energyMWhSinceMidnight: Number(totalConsumption/1000).toFixed(2)
      };
    } catch (error) {
      console.error('Error calculating total power usage:', error);
      throw error;
    }
},

  feedManualEntries: async (entries) => {
    try {
      await ContainerManualEntry.destroy({
        where: {
          [Op.or]: entries.map(entry => ({
            [Op.and]: [
              { start_time: { [Op.lte]: entry?.start_time } },
              { end_time: { [Op.gte]: entry?.end_time } }
            ]
          }))
        }
      });

      const createdEntries = await ContainerManualEntry.bulkCreate(
        entries.map(entry => ({
          start_time: entry?.start_time,
          end_time: entry?.end_time,
          power_value: entry?.value,
          days_to_send: entry?.daysToSend || 1
        }))
      );

      return { createdEntries };
    } catch (error) {
      console.error("Error processing manual entries:", error);
      throw new AppError("Error processing manual entries:", 500);

    }
  },

  getTomorrowTimeSlots: async () => {
    try {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(0, 0, 0, 0);

      const endOfTomorrow = new Date(tomorrow);
      endOfTomorrow.setHours(23, 59, 59, 999);

      const timeSlots = await ContainerManualEntry.findAll({
        attributes: ['id', 'start_time', 'end_time', 'power_value'], // Explicitly list columns
        where: {
          start_time: {
            [Op.between]: [tomorrow, endOfTomorrow]
          }
        },
        order: [['start_time', 'ASC']]
      });

      return { timeSlots };
    } catch (error) {
      console.error('Error getting time slots:', error);
      throw new AppError("Error getting time slots:", 500);
    }
  },

  createTimeSlot: async (payload) => {
    try {
      const { start_time, end_time, power_value } = payload;

      // Validate time slot is for tomorrow
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(0, 0, 0, 0);

      const existingSlot = await ContainerManualEntry.findOne({
        attributes: ['id', 'start_time', 'end_time', 'power_value'], // Explicitly list columns
        where: {
          [Op.or]: [
            {
              start_time: { [Op.lt]: end_time },
              end_time: { [Op.gt]: start_time }
            }
          ]
        }
      });

      if (existingSlot) {
        throw new AppError('Time slot overlaps with existing slot', 400);
      }

      const timeSlot = await ContainerManualEntry.create({
        start_time,
        end_time,
        power_value
      }, {
        fields: ['start_time', 'end_time', 'power_value'] // Explicitly list fields to insert
      });

      return { timeSlot };
    } catch (error) {
      console.error('Error creating time slot:', error);
      throw new AppError("Error creating time slot: " + error.message, 500);
    }
  },

  deleteTimeSlot: async (id) => {
    try {
      await ContainerManualEntry.destroy({ where: { id } });
      return true
    } catch (error) {
      console.error('Error deleting time slot:', error);
      throw new AppError("Error deleting time slot:", 500);
    }
  },

  getTimeSlotsByDateRange: async (startDate, endDate) => {
    try {
      const start = moment(startDate).startOf('day');
      const end = moment(endDate).endOf('day');

      const timeSlots = await ContainerManualEntry.findAll({
        where: {
          start_time: {
            [Op.gte]: start.toDate(),
            [Op.lte]: end.toDate()
          }
        },
        order: [['start_time', 'ASC']],
        raw: true
      });
      return { timeSlots };
    } catch (error) {
      console.error('Error getting time slots:', error);
      throw new AppError("Error getting time slots", 500);
    }
  },

  createTimeSlots: async (slots) => {
    try {
      // First delete any overlapping slots
      for (const slot of slots) {
        const start = moment(slot?.start_time);
        const end = moment(slot?.end_time);
        if (end?.diff(start, 'hours') < 1) {
          throw new Error('Time slot must be at least 1 hour');
        }
      }

      await ContainerManualEntry.destroy({
        where: {
          [Op.or]: slots.map(slot => ({
            [Op.and]: [
              { start_time: { [Op.lt]: slot?.end_time } },
              { end_time: { [Op.gt]: slot?.start_time } }
            ]
          }))
        }
      });

      const createdSlots = await ContainerManualEntry.bulkCreate(slots, {
        returning: true
      });
      return {
        timeSlots: createdSlots?.map(slot => ({
          id: slot?.id,
          start_time: slot?.start_time,
          end_time: slot?.end_time,
          power_value: slot?.power_value
        })) || []
      };
    } catch (error) {
      console.error('Error creating time slots:', error);
      throw new AppError("Error creating time slots", 500);
    }
  },

  getConfigs: async (req) => {
    try {
      const { page = 1, pageSize = 10 } = req.query;
      const offset = (page - 1) * pageSize;
      const { count, rows: configs } = await AlertConfig.findAndCountAll({
        order: [['displayName', 'ASC']],
        limit: parseInt(pageSize),
        offset: parseInt(offset)
      });
      return { configs, total: count, page: parseInt(page), pageSize: parseInt(pageSize) }
    } catch (error) {
      console.error('Error getting alerts', error);
      throw new AppError("Error getting alerts", 500);
    }
  },

  updateConfig: async (req) => {
    const { id } = req.params;
    const { field, displayName, conditionType, value, enabled } = req.body;
    const config = await AlertConfig.findByPk(id);
    if (!config) {
      throw new AppError('Alert not found', 404);
    }

    await config.update({ field, displayName, conditionType, value, enabled });
    return { config };
  },
  
  addConfig: async (req) => {
    const { field, displayName, conditionType, value, enabled } = req.body;
    const config = await AlertConfig.create({ field, displayName, conditionType, value, enabled });
    return { config };
  },

  deleteConfig: async (id) => {
    const config = await AlertConfig.findByPk(id);
    if (!config) {
      throw new AppError('Alert not found', 404);
    }

    await config.destroy();
  }
};
