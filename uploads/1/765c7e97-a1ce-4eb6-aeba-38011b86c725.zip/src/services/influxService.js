const { InfluxDB, Point } = require("@influxdata/influxdb-client");
const { parseDuration, getLiveStart, convertTHtoEH } = require("../utils/utils");
const { DateTime } = require("luxon");
const { writeApiPool } = require("../config");
const AppError = require("../utils/appError");
const { graphTimeRanges } = require("../utils/constants");

const influxDB = new InfluxDB({
  url: process.env.INFLUXDB_URL,
  token: process.env.INFLUXDB_TOKEN,
});

const queryApi = influxDB.getQueryApi(process.env.INFLUXDB_ORG);
module.exports = {
  getMinerTimeSeriesData: async (ip, timeRange = '24h') => {
    if (!graphTimeRanges[timeRange]) throw new Error('Invalid time range');
    const { flux: fluxRange, interval } = graphTimeRanges[timeRange];
    const fluxQuery = `
      from(bucket: "${process.env.INFLUXDB_BUCKET}")
        |> range(start: -${fluxRange})
        |> filter(fn: (r) => r._measurement == "miner_metrics")
        |> filter(fn: (r) => r.ip == "${ip}")
        |> filter(fn: (r) => r._field == "hashrate" or r._field == "temp0" or r._field == "temp1" or r._field == "temp2")
        |> aggregateWindow(every: ${interval}, fn: mean, createEmpty: false)
        |> pivot(rowKey: ["_time"], columnKey: ["_field"], valueColumn: "_value")
    `;

    const result = {
      hashrate: [],
      temp0: [],
      temp1: [],
      temp2: [],
    };

    const rows = await queryApi.collectRows(fluxQuery);

    for (const row of rows) {
      const time = new Date(row._time);

      if (row.hashrate !== undefined) {
        result.hashrate.push({ time, value: row.hashrate });
      }
      if (row.temp0 !== undefined) {
        result.temp0.push({ time, value: row.temp0 });
      }
      if (row.temp1 !== undefined) {
        result.temp1.push({ time, value: row.temp1 });
      }
      if (row.temp2 !== undefined) {
        result.temp2.push({ time, value: row.temp2 });
      }
    }

    return result;
  },

  getAllMinersTimeSeriesData: async (timeRange = '24h') => {
    const config = graphTimeRanges[timeRange];
    if (!config) throw new Error("Invalid time range");

    const now = new Date();
    const nowISOString = now.toISOString();

    const durationMs = parseDuration(config.flux); 
    const startTime = new Date(now.getTime() - durationMs);
    const startISOString = startTime.toISOString();

    const liveStart = getLiveStart(now, config.interval);
    const liveStartISOString = liveStart.toISOString();
    const downsampleQuery = `
    from(bucket: "${config.bucket}")
      |> range(start: time(v: "${startISOString}"))
      |> filter(fn: (r) => r._measurement == "miner_metrics_downsampled")
      |> filter(fn: (r) => r._field == "hashrate")
      |> keep(columns: ["_time", "_value"])
      |> yield(name: "downsample")
  `;
    const liveQuery = `
    from(bucket: "miner_metrics")
      |> range(start: time(v: "${liveStartISOString}"), stop: time(v: "${nowISOString}"))
      |> filter(fn: (r) => r._measurement == "miner_metrics")
      |> filter(fn: (r) => r._field == "hashrate")
      |> aggregateWindow(every: ${config.interval}, fn: mean, createEmpty: false)
      |> group(columns: ["_time"])
      |> sum()    
      |> yield(name: "live")
  `;
  
    const result = [];
    for (const query of [downsampleQuery, liveQuery]) {
      for await (const { values, tableMeta } of queryApi.iterateRows(query)) {
        const row = tableMeta.toObject(values);
        const valuePH = convertTHtoEH(row._value);
        result.push({
          date: new Date(row._time).toISOString(),
          value: Number(valuePH.toFixed(2)),
        });
      }
    }
    return result;
  },

  storePoolDataInflux: async (poolData) => {
    try {
      const { ip, mac_address, data } = poolData;
      if (!data || typeof data !== 'string') {
        return;
      }
      const jsonStart = poolData?.data?.indexOf('{');
      const jsonEnd = poolData?.data?.lastIndexOf('}');
      if (jsonStart === -1 || jsonEnd === -1) {
        return;
      }

      const cleanJsonStr = poolData?.data?.substring(jsonStart, jsonEnd + 1);
      const parsedData = JSON.parse(cleanJsonStr);

      const pools = parsedData?.POOLS || [];

      const timestamp = new Date();

      const points = pools?.map((pool, index) => {
        return new Point('miner_pool_metrics')
          .tag('mac', mac_address || 'unknown')
          .tag('ip', ip || 'unknown')
          .tag('pool_index', index.toString())
          .tag('pool_url', pool?.url || 'unknown')
          .tag('pool_user', pool?.user || 'unknown')
          .tag('pool_status', pool?.status || 'unknown')
          .intField('accepted', pool?.accepted || 0)
          .intField('rejected', pool?.rejected || 0)
          .intField('stale', pool?.stale || 0)
          .floatField('difficulty', parseFloat(pool?.diff?.replace('M', '') || '0') * 1_000_000)
          .booleanField('is_active', pool?.status === 'Alive')
          .timestamp(timestamp);
      });

      for (const point of points) {
        writeApiPool.writePoint(point);
      }
      await writeApiPool.flush();
    } catch (error) {
      console.error('Error storing pool data:', error);
      throw new AppError('Failed to store pool data', 500);
    }
  },

  getPoolTimeSeries: async (ip, timeRange = '24h') => {
    const fluxQuery = `
    from(bucket: "${process.env.INFLUXDB_POOL_BUCKET}")
      |> range(start: -${timeRange})
      |> filter(fn: (r) => r._measurement == "miner_pool_metrics")
      |> filter(fn: (r) => r.ip == "${ip}")
      |> pivot(rowKey: ["_time", "pool_index"], columnKey: ["_field"], valueColumn: "_value")
    `;

    const result = {
      pools: {},
    };

    for await (const { values, tableMeta } of queryApi.iterateRows(fluxQuery)) {
      const rowObject = tableMeta.toObject(values);
      const poolIndex = rowObject?.pool_index || "unknown";

      if (!result.pools[poolIndex]) {
        result.pools[poolIndex] = {
          pool_url: rowObject?.pool_url || "unknown",
          pool_user: rowObject?.pool_user || "unknown",
          pool_status: rowObject?.pool_status || "unknown",
          accepted: [],
          rejected: [],
          stale: [],
          difficulty: [],
          is_active: []
        };
      }

      if (rowObject.accepted !== undefined) {
        result.pools[poolIndex].accepted.push({
          time: new Date(rowObject._time),
          value: rowObject.accepted,
        });
      }
      if (rowObject.rejected !== undefined) {
        result.pools[poolIndex].rejected.push({
          time: new Date(rowObject._time),
          value: rowObject.rejected,
        });
      }
      if (rowObject.stale !== undefined) {
        result.pools[poolIndex].stale.push({
          time: new Date(rowObject._time),
          value: rowObject.stale,
        });
      }
      if (rowObject.difficulty !== undefined) {
        result.pools[poolIndex].difficulty.push({
          time: new Date(rowObject._time),
          value: rowObject.difficulty,
        });
      }
      if (rowObject.is_active !== undefined) {
        result.pools[poolIndex].is_active.push({
          time: new Date(rowObject._time),
          value: rowObject.is_active,
        });
      }
    }

    if (Object.keys(result.pools).length === 0) {
      console.warn("No pool data returned. Possible issues: No matching data, incorrect measurement/field, or time range too narrow.");
    }

    return result;
  },

 getAllPoolsTimeSeries: async (timeRange = '24h') => {
  try {
    const result = [];
    const now = DateTime.utc();
    const startOfCurrentHour = now.startOf("hour");
    const hourlyFlux = `
      from(bucket: "${process.env.INFLUXDB_POOL_HOURLY_BUCKET}")
        |> range(start: -${timeRange})
        |> filter(fn: (r) => r._measurement == "miner_pool_metrics")
        |> filter(fn: (r) => r._field == "accepted" or r._field == "rejected" or r._field == "stale")
        |> keep(columns: ["_time", "_field", "_value"])
    `;
    const groupedByHour = {};

    for await (const { values, tableMeta } of queryApi.iterateRows(hourlyFlux)) {
      const row = tableMeta.toObject(values);
      const hourKey = DateTime.fromISO(row._time, { zone: 'utc' }).startOf('hour').toISO({ suppressMilliseconds: true });

      if (!groupedByHour[hourKey]) {
        groupedByHour[hourKey] = { accepted: 0, rejected: 0, stale: 0 };
      }

      const value = Number(row._value) || 0;
      groupedByHour[hourKey][row._field] += value;
    }
    const liveFlux = `
      from(bucket: "${process.env.INFLUXDB_POOL_BUCKET}")
        |> range(start: ${startOfCurrentHour.toISO()}, stop: now())
        |> filter(fn: (r) => r._measurement == "miner_pool_metrics")
        |> filter(fn: (r) => r._field == "accepted" or r._field == "rejected" or r._field == "stale")
        |> aggregateWindow(every: 1h, fn: sum, createEmpty: false)
        |> group(columns: ["_field"])
        |> sum()
        |> keep(columns: ["_time", "_field", "_value"])
    `;

    const liveMetrics = { accepted: 0, rejected: 0, stale: 0 };
    const liveHourKey = startOfCurrentHour.toISO({ suppressMilliseconds: true });

    for await (const { values, tableMeta } of queryApi.iterateRows(liveFlux)) {
      const row = tableMeta.toObject(values);
      const value = Number(row._value) || 0;
      liveMetrics[row._field] += value;
    }
  
    for (let i = 23; i >= 1; i--) {
      const hourTime = startOfCurrentHour.minus({ hours: i });
      const hourKey = hourTime.toISO({ suppressMilliseconds: true });
      const metrics = groupedByHour[hourKey] || { accepted: 0, rejected: 0, stale: 0 };
      result.push({ date: hourKey, ...metrics });
    }
    result.push({ date: liveHourKey, ...liveMetrics });
    return result;
  } catch (error) {
    console.error("Error in getAllPoolsTimeSeries:", error);
    throw new Error("Failed to get all pools time series data");
  }
},
};
