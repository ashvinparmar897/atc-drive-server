const { redisClientRead, redisClient } = require("../config");
const AppError = require("../utils/appError");
const { MINER_STATUSES } = require("../utils/constants");
const { determineMinerStatus, buildMinerFromData, tryParseJson } = require("../utils/utils");

module.exports = {
  getMiners: async (page, pageSize, statusFilter, userId) => {
    if (!redisClientRead.isOpen) {
      await redisClientRead.connect();
    }
    const userSettings = await redisClientRead.hGetAll(`user:${userId}:settings`);
    try {
      if (statusFilter && !Object.values(MINER_STATUSES).includes(statusFilter)) {
        throw new AppError(`Invalid status filter: ${statusFilter}`, 400);
      }

      const minerKeys = await redisClientRead.keys('miner:*');
      const miners = await Promise.all(
        minerKeys.map(async (key) => {
          const minerData = await redisClientRead.hGetAll(key);
          if (!minerData || Object.keys(minerData).length === 0) return null;

          const miner = buildMinerFromData(key, minerData);
          miner.status = determineMinerStatus(miner, userSettings);
          if (statusFilter && miner.status !== statusFilter) return null;

          return miner;
        })
      );

      const filteredMiners = miners.filter(Boolean);
      const totalCount = filteredMiners.length;

      const paginatedMiners = (page && pageSize)
        ? filteredMiners.slice((page - 1) * pageSize, page * pageSize)
        : filteredMiners;

      return {
        miners: paginatedMiners,
        totalCount,
        page: page || 1,
        pageSize: pageSize || paginatedMiners.length,
      };

    } catch (error) {
      console.error('Error in getMiners:', error);
      throw new AppError(`Error while fetching miners list: ${error.message}`, 500);
    }
  },

  saveThresholdSettings: async (userId, settings) => {
    await redisClient.hSet(`user:${userId}:settings`, {
      fanFaultThreshold: settings.fanFaultThreshold,
      highTempThreshold: settings.highTempThreshold,
      highRejectRateThreshold: settings.highRejectRateThreshold
    });
  },

  getThresholdSettings: async (userId) => {
    const threshold = await redisClientRead.hGetAll(`user:${userId}:settings`);
    if (threshold) {
      return { threshold }
    } else {
      return { threshold: [] }
    }
  },

  setPoolData : async (mac, data) => {
    if (!mac || !data) return;
    
    if (!redisClient?.isOpen) {
      await redisClient.connect().catch(console.error);
    }
    const normalizeMac = (mac) => mac?.replace(/:/g, "").toLowerCase();

  const macSanitized = normalizeMac(mac);
  const key = `pool:${macSanitized}`;

  try {
    await redisClient.set(key, JSON.stringify(data));
  } catch (err) {
    console.error("❌ Redis setPoolData error:", err);
  }
  },

  getPoolData : async(mac)=> {
    if (!mac) return null;

    if (!redisClient?.isOpen) {
      await redisClient.connect().catch(console.error);
    }
    const normalizeMac = (mac) => mac?.replace(/:/g, "").toLowerCase();
    const macSanitized = normalizeMac(mac);
    const key = `pool:${macSanitized}`;

    try {
      const dataStr = await redisClient.get(key);
      return tryParseJson(dataStr);
    } catch (err) {
      console.error("❌ Redis getPoolData error:", err);
      return null;
    }
  },
};
