const { redisClient } = require("../config");
const { IpRange } = require("../config/database");
const AppError = require("../utils/appError");

const getAllIpRanges = async () => {
  return await IpRange.findAll({ order: [["created_at", "DESC"]] });
};

const createIpRange = async (data) => {
  if (!data?.ip_range) {
    throw new AppError("IP Range is required", 400);
  }

  const newIpRange = await IpRange.create({
    ip_range: data.ip_range,
    container_name: data.container_name || null,
    miner_manufacturer: data.miner_manufacturer,
  });

  const redisKey = `iprange:${newIpRange.ip_range}`;
  await redisClient.hSet(redisKey, {
    ip_range: newIpRange.ip_range,
    container_name: newIpRange.container_name || "",
    miner_manufacturer: newIpRange.miner_manufacturer || ""
  });

  return newIpRange;
};

const updateIpRange = async (id, data) => {
  const ipRange = await IpRange.findByPk(id);
  if (!ipRange) throw new AppError("IP Range not found", 404);

  ipRange.ip_range = data.ip_range || ipRange.ip_range;
  ipRange.container_name = data.container_name || ipRange.container_name;
  ipRange.miner_manufacturer = data.miner_manufacturer || ipRange.miner_manufacturer;
  await ipRange.save();

  const redisKey = `iprange:${ipRange.ip_range}`;
  await redisClient.hSet(redisKey, {
    ip_range: ipRange.ip_range,
    container_name: ipRange.container_name || "",
    miner_manufacturer: ipRange.miner_manufacturer || "",
  });

  return ipRange;
};

const deleteIpRange = async (id) => {
  const ipRange = await IpRange.findByPk(id);
  if (!ipRange) throw new AppError("IP Range not found", 404);

  await ipRange.destroy();

  const redisKey = `iprange:${id}`;
  await redisClient.del(redisKey);
};

module.exports = {
  getAllIpRanges,
  createIpRange,
  updateIpRange,
  deleteIpRange,
};
