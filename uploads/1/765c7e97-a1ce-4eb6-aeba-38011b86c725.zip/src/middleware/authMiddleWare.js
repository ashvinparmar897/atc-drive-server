const jwt = require('jsonwebtoken');
const { User } = require('../config/database');

const JWT_SECRET = process.env.JWT_SECRET;

module.exports = async (req, res, next) => {
  try {
    const authHeader = req.get('Authorization');
    if (!authHeader) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    const token = authHeader.split(' ')[1];
    if (!token) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    let decodedToken;
    try {
      decodedToken = jwt.verify(token, JWT_SECRET);
    } catch (err) {
      if (err.name === 'TokenExpiredError') {
        return res.status(401).json({ message: 'Token expired' });
      }
      return res.status(401).json({ message: 'Invalid token' });
    }
    if (!decodedToken) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    const user = await User.findByPk(decodedToken.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    req.userId = decodedToken.userId;
    req.userRole = decodedToken.userRole;
    next();
  } catch (error) {
    console.error('Authentication error:', error);
    if (!error.statusCode) {
      error.statusCode = 500;
    }
    next(error);
  }
};