// middleware/validation.js
const { check } = require('express-validator');

exports.validateSignup = [
    check('name').trim().not().isEmpty().withMessage('Name is required'),
    check('email').isEmail().withMessage('Please enter a valid email'),
    check('password').trim().isLength({ min: 6 }).withMessage('Password must be at least 6 characters long')
];

exports.validateLogin = [
    check('email').isEmail().withMessage('Please enter a valid email'),
    check('password').trim().not().isEmpty().withMessage('Password is required')
];

exports.validatePoolData = [
    check('mac_address').trim().not().isEmpty().withMessage('MAC address is required'),
    check('data').trim().not().isEmpty().withMessage('Pool data is required')
];

exports.validateTimeRange = [
    check('timeRange').optional().isIn(['1h', '6h', '12h', '24h', '7d', '30d']).withMessage('Invalid time range. Use: 1h, 6h, 12h, 24h, 7d, 30d')
];

exports.validateDays = [
    check('days').optional().isInt({ min: 1, max: 30 }).withMessage('Days must be between 1 and 30')
];