const { Point } = require("@influxdata/influxdb-client");
const {
  Miner,
  MinerStat,
  Pool,
  sequelize,
} = require("../config/database");
const { redisClient, writeApi, redisClientRead } = require("../config");
const { validateFloat, chunkArray, parseFloatOrNull, formatMac, parseStatus, parseFloatArray } = require("../utils/utils");

async function combineAndStoreData(data) {
  try {
    const mac = data?.mac_address;
    const newHashrate = Number(data?.hashrate?.current || 0);

    if (!mac) throw new Error("Missing MAC address");

    const [prevHashrateStr] = await redisClient.hmGet('mac_to_hashrate', mac);
    const prevHashrate = Number(prevHashrateStr || 0);

    if (newHashrate !== prevHashrate) {
      const delta = newHashrate - prevHashrate;

      await redisClient.incrByFloat('total_hashrate', delta);

      await redisClient.hSet('mac_to_hashrate', mac, newHashrate);
    }

    await Promise.all([
      cacheInRedis(data),
      storeInInflux(data)
    ]);
  } catch (error) {
    console.error("Error in combineAndStoreData:", error);
    throw error;
  }
}

const getContainerNameFromIp = async (ip) => {
  if (!ip) return null;
  const keys = await redisClientRead.keys("iprange:*");
  for (const key of keys) {
    const rangeData = await redisClientRead.hGetAll(key);
    if (rangeData?.ip_range) {
      const normalizedRange = rangeData.ip_range.trim().replace(/\.0$/, "");
      if (ip.trim().startsWith(normalizedRange)) {
        return rangeData?.container_name || null;
      }
    }
  }
  return null;
};

function tryParseJson(input) {
  if (typeof input === 'object') return input;
  if (typeof input !== 'string' || !input.trim()) return null;
  try {
    return JSON.parse(input);
  } catch (e) {
    console.error("JSON parse error:", e.message);
    console.warn("Failed to parse JSON:", input);
    return null;
  }
}

async function storeInInflux(data) {
  try {
    const { ip, mac_address } = data;
    const { miner_id } = data.miner_info;
    const timestamp = data?.timestamp;

    const hashratePoint = new Point("miner_metrics")
      .tag("mac", mac_address)
      .tag("ip", ip)
      .tag("miner_id", miner_id)
      .floatField("hashrate", validateFloat(data?.hashrate?.current))
      .timestamp(timestamp);

    writeApi.writePoint(hashratePoint);

    data?.temperature?.values.forEach((temp, index) => {
      const tempPoint = new Point("miner_metrics")
        .tag("mac", mac_address)
        .tag("ip", ip)
        .tag("miner_id", miner_id)
        .floatField(`temp${index}`, validateFloat(temp))
        .timestamp(timestamp);

      writeApi.writePoint(tempPoint);
    });

    await writeApi.flush();
  } catch (error) {
    console.error("Error in storeInInflux:", error);
    throw error;
  }
}

function safeString(value) {
  if (value === undefined || value === null) return "";
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}

async function cacheInRedis(data) {
  if (!redisClient?.isOpen) {
    try {
      await redisClient.connect();
    } catch (err) {
      console.error("Failed to reconnect to Redis:", err);
      return;
    }
  }

  const mac = data?.mac_address;
  if (!mac) return;

  const macSanitized = mac?.replace(/:/g, "");
  const minerKey = `miner:${macSanitized}`;
  const timestamp = Date.now();
  const containerName = await getContainerNameFromIp(data?.ip);

  try {
    const pools = data?.pool_info?.pools?.map?.((pool) => ({
      miner_mac: data?.mac_address,
      url: pool?.url,
      worker: pool?.user,
      status: pool?.status,
      priority: pool?.priority,
      accepted: pool?.accepted || 0,
      rejected: pool?.rejected || 0,
    }));

    const activeChainsValue = data?.chains?.values || [];
    const activeChainsInfo = typeof data?.chains?.info === "object"
      ? data?.chains?.info
      : tryParseJson(data?.chains?.info);

    const redisHash = {
      mac,
      ip: safeString(data?.ip),
      container_name: safeString(containerName),
      type: safeString(data?.miner_info?.type),
      model: safeString(data?.miner_info?.model),
      version: safeString(data?.miner_info?.version),
      compile_time: safeString(data?.miner_info?.compile_time),
      miner_id: safeString(data?.miner_info?.miner_id),
      agent_id: safeString(data?.miner_info?.agent_id),
      status: "online",
      workingMode: "Normal",
      hashrate: data?.hashrate?.current?.toString(),
      temp_max: data?.temperature?.max?.toString(),
      fans: JSON.stringify(data?.fans?.values),

      hashrate_current: safeString(data?.hashrate?.current),
      hashrate_average: safeString(data?.hashrate?.average),
      hashrate_30m: safeString(data?.hashrate?.rate_30m),
      hashrates: safeString(data?.hashrate?.values),
      temperatures: JSON.stringify(data?.temperature?.values),

      temperature_max: safeString(data?.temperature?.max),
      temperature_values: safeString(data?.temperature?.values),
      fan_speeds: safeString(data?.fans?.values),
      frequencies: safeString(data?.frequency?.values),
      frequency_avg: safeString(data?.frequency?.average),
      active_chains: safeString(activeChainsValue),
      active_chains_info: safeString(activeChainsInfo),

      pools: safeString(pools),
      last_updated: timestamp.toString(),
    };
    await redisClient.hSet(minerKey, redisHash);
  } catch (error) {
    console.error("Redis caching error:", error);
    if (error.message.includes("CLOSED")) {
      try {
        await redisClient.connect();
      } catch (reconnectError) {
        console.error("Redis reconnection failed:", reconnectError);
      }
    }
  }
}

async function syncMinerDataFromRedis() {
  try {
    if (!redisClientRead.isOpen) {
      await redisClientRead.connect();
    }
    const keys = await redisClientRead.keys('miner:*');

    if (!keys.length) {
      return;
    }
    const macAddressList = keys
      .map(key => {
        const mac = key.split('miner:')[1];
        return mac ? formatMac(mac) : null;
      })
      .filter(Boolean);

    const existingMiners = await Miner.findAll({
      where: { mac_address: macAddressList },
      attributes: ['mac_address', 'updated_at'],
      raw: true,
    });
    const dbMinerMap = new Map(
      existingMiners?.map(miner => [
        miner?.mac_address,
        new Date(miner?.updated_at).getTime(),
      ])
    );
    const updatedMiners = [];
    const CONCURRENCY = 200;

    for (let i = 0; i < keys.length; i += CONCURRENCY) {
      const batch = keys.slice(i, i + CONCURRENCY);
      await Promise.allSettled(
        batch.map(async key => {
          try {
            const minerData = await redisClientRead.hGetAll(key);
            if (!minerData?.mac || !minerData?.last_updated) return;

            let redisUpdatedAt = parseInt(minerData?.last_updated, 10);

            const dbUpdatedAt = dbMinerMap?.get(minerData?.mac) || 0;
            if (redisUpdatedAt > dbUpdatedAt) {
              updatedMiners.push(minerData);
            }
          } catch (err) {
            console.error(`❌ Redis error for key ${key}:`, err.message);
          }
        })
      );
    }
    if (!updatedMiners?.length) return;
    const minerChunks = chunkArray(updatedMiners, 200);
    for (const [i, chunk] of minerChunks.entries()) {
      const minersToInsert = [];
      const statsToInsert = [];
      const minerPoolsToUpsert = [];
      for (const data of chunk) {
        try {
          const updatedAt = new Date(
            Number(data?.last_updated) < 2e10
              ? Number(data?.last_updated) * 1000
              : Number(data?.last_updated)
          );

          minersToInsert.push({
            mac_address: formatMac(data?.mac),
            ip: data?.ip && data?.ip !== 'null' ? data?.ip : null,
            type: data.type || 'unknown',
            model: data?.model || null,
            version: data?.version || null,
            compile_time: data?.compile_time || null,
            miner_id: data?.miner_id || null,
            status: parseStatus(data.status),
            updated_at: updatedAt,
          });
          statsToInsert.push({
            miner_mac: formatMac(data.mac),
            hashrate_current: parseFloatOrNull(data.hashrate_current),
            hashrate_average: parseFloatOrNull(data.hashrate_average),
            hashrate_30m: parseFloatOrNull(data.hashrate_30m),
            temperature_values: parseFloatArray(data.temperature_values),
            temperature_max: parseFloatOrNull(data.temperature_max),
            fan_speeds: parseFloatArray(data.fan_speeds),
            frequencies: parseFloatArray(data.frequencies),
            hashrates: parseFloatArray(data.hashrates),
            frequency_avg: parseFloatOrNull(data.frequency_avg),
            active_chains: parseFloatArray(data.active_chains),
            active_chains_info: tryParseJson(data.active_chains_info),
            updated_at: updatedAt,
          });
          minerPoolsToUpsert.push({
            miner_mac: formatMac(data?.mac),
            pools: tryParseJson(data?.pools) || [],
            updated_at: updatedAt,
          });
        } catch (err) {
          console.error(`❌ Failed to parse miner data for ${data?.mac}`, err.message);
        }
      }
      let transaction;
      try {
        transaction = await sequelize.transaction();

        await Miner.bulkCreate(minersToInsert, {
          updateOnDuplicate: [
            'ip', 'type', 'model', 'version',
            'compile_time', 'miner_id', 'status', 'updated_at',
          ],
          transaction,
        });
        await MinerStat.bulkCreate(statsToInsert, {
          updateOnDuplicate: [
            'hashrate_current', 'hashrate_average', 'hashrate_30m',
            'temperature_values', 'temperature_max', 'fan_speeds',
            'frequencies', 'frequency_avg', 'hashrates',
            'active_chains', 'active_chains_info', 'updated_at',
          ],
          transaction,
        });
        if (minerPoolsToUpsert.length > 0) {
          await Pool.bulkCreate(minerPoolsToUpsert, {
            updateOnDuplicate: ['pools', 'updated_at'],
            transaction,
          });
        }
        await transaction.commit();
      } catch (err) {
        if (transaction) await transaction.rollback();
        console.error(`❌ Failed to write chunk ${i + 1}:`, err.message);
        console.error(err.stack);
      }
    }
  } catch (err) {
    console.error('🔥 Fatal sync error:', err.message);
    console.error(err.stack);
  }
}
module.exports = { combineAndStoreData, syncMinerDataFromRedis };
