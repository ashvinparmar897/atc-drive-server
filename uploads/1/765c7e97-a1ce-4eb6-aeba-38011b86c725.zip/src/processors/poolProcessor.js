function processPoolData(pool) {
  try {
    if (!pool?.data) {
      return {
        pools: [],
        active_pool: null,
      };
    }
    let rawData = pool.data;
    if (typeof rawData === 'string') {
      const trimmed = rawData.trim();
      if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
        try {
          rawData = JSON.parse(trimmed);
        } catch (parseError) {
          console.error(`JSON parse error for pool ${pool.ip}:`, parseError);
          throw new Error(`Invalid JSON pool data for IP ${pool.ip}`);
        }
      } else {
        return {
          pools: [],
          active_pool: null,
          raw_message: trimmed,
        };
      }
    }
    const pools = (rawData?.POOLS ?? []).map((p) => ({
      url: p?.url,
      user: p?.user,
      status: p?.status,
      priority: p?.priority,
      accepted: p?.accepted ?? 0,
      rejected: p?.rejected ?? 0,
      stale: p?.stale ?? 0,
      difficulty: p?.diff ?? 0,
    }));

    const activePool = pools.find((p) => p.status === 'Alive')?.url ?? null;

    return {
      pools,
      active_pool: activePool,
    };
  } catch (error) {
    console.error(`Error processing pool data for ${pool?.ip}:`, error);
    throw new Error(`Failed to process pool data: ${error.message}`);
  }
}

module.exports = { processPoolData };
