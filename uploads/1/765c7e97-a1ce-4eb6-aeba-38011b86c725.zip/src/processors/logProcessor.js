function processMinerLog(log) {
  const stats = log?.data?.STATS?.[1];
  const info = log?.data?.STATS?.[0];
  
  const convertToTHS = (value) =>
    stats?.rate_unit === "GH" ? value / 1000 : value;

  return {
    ip: log.ip,
    mac_address: log.mac_address,
    miner_info: {
      type: info.Type,
      model: info.Model || "",
      version: info.Miner,
      compile_time: info.CompileTime,
      miner_id: stats?.miner_id || '',
    },
    hashrate: {
      current: convertToTHS(stats?.["GHS 5s"] || 0),
      average: convertToTHS(stats?.["GHS av"] || 0),
      values: [1, 2, 3].map((i) => convertToTHS(stats?.[`chain_rate${i}`])),
      rate_30m: convertToTHS(stats?.rate_30m),
      unit: "TH",
    },
    temperature: {
      values: [1, 2, 3].map((i) => stats?.[`temp2_${i}`]),
      max: Math.max(
        ...Object.entries(stats || {})
          .filter(([key]) => key?.startsWith("temp2_") && key !== "temp2")
          .map(([, value]) => value)
      ),
    },
    fans: {
      values: [1, 2, 3, 4].map((i) => stats?.[`fan${i}`]),
    },
    frequency: {
      values: [1, 2, 3].map((i) => stats?.[`freq${i}`]),
      average: stats?.total_freqavg,
    },
    chains: {
      active: stats?.total_acn,
      values: [1, 2, 3].map((i) => stats?.[`chain_acn${i}`] || 0),
      info: [1, 2, 3].map((i) => stats?.[`chain_acs${i}`] || ""),
    },
    timestamp: new Date(),
  };
}

function upadatedProcessMinerLog(log) {
  const stats = log?.data?.STATS?.[0];
  const info = log?.data?.INFO;
  
  const convertToTHS = (value) =>
    stats?.rate_unit === "GH" ? value / 1000 : value;

  return {
    ip: log.ip,
    mac_address: log.mac_address,
    miner_info: {
      type: "",
      model:  "",
      version: info.miner_version,
      compile_time: info.CompileTime,
      miner_id: "",
    },
    hashrate: {
      current: convertToTHS(stats?.rate_5s || 0),
      average: convertToTHS(stats?.rate_avg || 0),
      values: stats?.chain?.map((chain) => convertToTHS(chain.rate_real)) || [0, 0, 0],
      rate_30m: convertToTHS(stats?.rate_30m || 0),
      unit: "TH",
    },
    temperature: {
    values: stats?.chain?.map((chain) => Math.max(...(chain.temp_chip || [0]))) || [0, 0, 0],
    max: Math.max(
      ...(stats?.chain?.flatMap((chain) => chain.temp_chip || [0]) || [0])
    ),
    },
    fans: {
      values: stats?.fan || [0, 0, 0, 0],
    },
    frequency: {
      values: stats?.chain?.map((chain) => chain.freq_avg || 0) || [0, 0, 0],
      average: stats?.chain?.reduce((sum, chain) => sum + (chain.freq_avg || 0), 0) / (stats?.chain?.length || 1),
    },
    chains: {
      active: stats?.chain?.reduce((sum, chain) => sum + (chain.asic_num || 0), 0) || 0,
      values: stats?.chain?.map((chain) => chain.asic_num || 0) || [0, 0, 0],
      info: stats?.chain?.map((chain) => chain.tpl?.flat().join(" ") || "") || ["", "", ""],
    },
    timestamp: new Date(),
  };
}

module.exports = { processMinerLog, upadatedProcessMinerLog };
