const {
  getAllIpRanges,
  createIpRange,
  updateIpRange,
  deleteIpRange,
} = require("../services/ipRangeService");

exports.getAllIpRanges = async (req, res, next) => {
  try {
    const ranges = await getAllIpRanges();
    return res.status(200).json({ data: ranges, status: true });
  } catch (error) {
    next(error);
  }
};

exports.createIpRange = async (req, res, next) => {
  try {
    const newRange = await createIpRange(req.body);
    return res.status(201).json({ data: newRange, status: true });
  } catch (error) {
    next(error);
  }
};

exports.updateIpRange = async (req, res, next) => {
  try {
    const updated = await updateIpRange(req.params.id, req.body);
    return res.status(200).json({ data: updated, status: true });
  } catch (error) {
    next(error);
  }
};

exports.deleteIpRange = async (req, res, next) => {
  try {
    await deleteIpRange(req.params.id);
    return res.status(200).json({ message: "Deleted successfully", status: true });
  } catch (error) {
    next(error);
  }
};
