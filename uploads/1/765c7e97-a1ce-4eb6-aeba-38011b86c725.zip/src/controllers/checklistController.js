const {
    getChecklists,
    getChecklistDetails,
    submitChecklistResponse,
    getUserChecklistResponses,
    getChecklistResponseDetails,
    getUsersWithChecklists,
    updateChecklistAnswers
} = require("../services/checklistService");

exports.getChecklists = async (req, res, next) => {
    try {
        const checklists = await getChecklists();
        res.status(200).json({
            status: true,
            checklists
        });
    } catch (error) {
        next(error);
    }
};

exports.getChecklistDetails = async (req, res, next) => {
    try {
        const checklist = await getChecklistDetails(req?.params?.id);
        res.status(200).json({
            status: true,
            checklist
        });
    } catch (error) {
        next(error);
    }
};

exports.submitChecklist = async (req, res, next) => {
    try {
        const response = await submitChecklistResponse({
            ...req.body,
            checklist_id: req?.params?.id,
            user_id: req?.userId
        });
        res.status(200).json({
            status: true,
            message: "Checklist submitted successfully",
            response
        });
    } catch (error) {
        next(error);
    }
};

exports.getUserResponses = async (req, res, next) => {
    try {
        const { count, rows } = await getUserChecklistResponses(
            req?.userId,
            req?.params.id,
            req?.query,
        );
        res.status(200).json({
            status: true,
            responses: rows,
            total: count,
            page: parseInt(req?.query?.page || 1),
            pageSize: parseInt(req?.query?.pageSize || 10)
        });
    } catch (error) {
        next(error);
    }
};

exports.getResponseDetails = async (req, res, next) => {
    try {
        const response = await getChecklistResponseDetails(req.params.id);
        if (req.userRole !== 'Admin' && response?.user?.id !== req?.userId) {
            return res.status(403).json({
                status: false,
                message: "You don't have permission to view this checklist"
            });
        }

        res.status(200).json({
            status: true,
            response
        });
    } catch (error) {
        next(error);
    }
};

exports.updateAnswers = async (req, res, next) => {
    try {
        const result = await updateChecklistAnswers(
            req?.params?.id,
            req?.body,
            req?.userId
        );
        res.status(200).json({
            status: true,
            message: "Answers updated successfully",
            result
        });
    } catch (error) {
        next(error);
    }
};

exports.getUsersWithChecklists = async (req, res, next) => {
    try {
        if (req?.userRole !== 'Admin') {
            return res.status(403).json({
                status: false,
                message: "Only admin can access this resource"
            });
        }

        const data = await getUsersWithChecklists(req.query);
        res.status(200).json({
            status: true,
            users: data?.users,
            total: data?.total,
            page: parseInt(req?.query?.page || 1),
            pageSize: parseInt(req?.query?.pageSize || 10)
        });
    } catch (error) {
        next(error);
    }
};