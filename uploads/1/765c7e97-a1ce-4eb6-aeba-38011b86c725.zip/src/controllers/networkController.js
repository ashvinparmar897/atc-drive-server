const { getProfit, getStrikePrice } = require("../services/networkService");
exports.getProfit = async (req, res, next) => {
  try {
    const {
      petaHashPerDay,
      electricityConsumption,
      price,
      noOfDays,
      currency,
    } = req.query;

    if (
      !petaHashPerDay ||
      !electricityConsumption ||
      !price ||
      !noOfDays ||
      !currency
    ) {
      res.status(200).json({
        data: [],
        status: false,
        message:
          "Missing Details: Hashrate, Electricity Consumption, Price, No Of Days, Currency",
      });
    } else {
      const result = await getProfit(req.query);

      if (result && result?.profit && result?.hashPrice) {
        return res.status(200).json({
          data: {
            profit: result?.profit,
            hashprice: result?.hashPrice,
          },
          status: true,
        });
      } else {
        return res.status(200).json({
          data: [],
          status: true,
          message: "Unable to calculate profit",
        });
      }
    }
  } catch (error) {
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};

exports.getStrikePrice = async (req, res, next) => {
  try {
    const { minerType, currency } = req.query;
    if (!minerType || !currency) {
      res.status(200).json({
        data: [],
        status: false,
        message: "Please provide your miner name or currency",
      });
    }

    const result = await getStrikePrice(req.query);
    if (result) {
      return res.status(200).json({
        data: result,
        status: true,
      });
    } else {
      return res.status(200).json({
        data: [],
        status: false,
        message: "Unable to find strike price",
      });
    }
  } catch (error) {
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};
