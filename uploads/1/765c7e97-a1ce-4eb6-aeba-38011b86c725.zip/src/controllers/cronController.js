const { getCronSchedule, updateCronSchedule } = require("../services/cronService");
exports.getCron = async (req, res, next) => {
    try {
        const { schedule } = await getCronSchedule();

        if (schedule) {
            return res.status(200).json({
                schedule,
                status: true,
            });
        } else {
            return res.status(200).json({
                data: [],
                status: false,
                message: "Unable to fetch cron job",
            });
        }
    } catch (error) {
        console.log(error, "error");
        if (!error.statusCode) {
            return (error.statusCode = 500);
        }
        next(error);
    }
};

exports.UpdateCron = async (req, res, next) => {
    try {

        const { frequencyDays } = req.body;

        if (!frequencyDays) {
            return res.status(400).json({ error: 'Missing Frequency' });
        }
        if (frequencyDays < 7 || frequencyDays > 365) {
            return res.status(400).json({ error: 'Frequency must be between 7 and 30 days' });
        }
        const { schedule } = await updateCronSchedule(frequencyDays)
        if (schedule) {
            return res.status(200).json({
                schedule,
                message: "Cron Updated successfully",
                status: true,
            });
        } else {
            return res.status(200).json({
                data: [],
                status: false,
                message: "Unable to update cron schedule",
            });
        }
    } catch (error) {
        console.log(error, "error");
        if (!error.statusCode) {
            return (error.statusCode = 500);
        }
        next(error);
    }
};
