const { getRolesList } = require("../services/rolesService");

exports.getList = async (req, res, next) => {
  try {
    const { roles } = await getRolesList(req);

    if (roles) {
      return res.status(200).json({
        roles,
        status: true,
      });
    } else {
      return res.status(200).json({
        data: [],
        status: false,
        message: "Unable to fetch roles",
      });
    }
  } catch (error) {
    console.log(error, "error");
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};




