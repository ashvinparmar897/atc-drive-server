const { getBitcoinPrice } = require("../services/bitcoinService");

exports.getBitcoinPrice = async (req, res, next) => {
  try {
    const bitcoinData = await getBitcoinPrice();
    
    return res.status(200).json({
      bitcoinData,
      status: true,
    });
  } catch (error) {
    if (!error.statusCode) {
      error.statusCode = 500;
    }
    next(error);
  }
};
