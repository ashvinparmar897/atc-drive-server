const { getContainerDetails, feedManualEntries, createTimeSlot, deleteTimeSlot, getTomorrowTimeSlots, createTimeSlots, getTimeSlotsByDateRange, getConfigs, updateConfig, addConfig, deleteConfig, getContainerNames } = require("../services/containerService");
exports.getList = async (req, res, next) => {
  try {
    const { containers } = await getContainerDetails();

    if (containers) {
      return res.status(200).json({
        data: {
          containers,
        },
        status: true,
      });
    } else {
      return res.status(200).json({
        data: [],
        status: false,
        message: "Unable to fetch containers",
      });
    }
  } catch (error) {
    console.log(error, "error");
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};

exports.getContainerNames = async (req, res, next) => {
  try {
    const { containerNames } = await getContainerNames();

    if (containerNames) {
      return res.status(200).json({
        data: {
          containerNames,
        },
        status: true,
      });
    } else {
      return res.status(200).json({
        data: [],
        status: false,
        message: "Unable to fetch containers name",
      });
    }
  } catch (error) {
    console.log(error, "error");
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};

exports.feedEntries = async (req, res, next) => {
  try {
    const { entries } = req.body;
    if (!entries || !entries?.length) {
      return res.status(200).json({
        status: false,
        message: "Missing details time range , date , values, days to send",
      });
    }
    const { createdEntries } = await feedManualEntries(entries);
    if (createdEntries) {
      return res.status(200).json({
        message: "Entries feeded successfully",
        status: true,
      });
    } else {
      return res.status(200).json({
        data: [],
        status: false,
        message: "Unable to feed enries",
      });
    }
  } catch (error) {
    console.log(error, "error");
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};
exports.createSlot = async (req, res, next) => {
  try {
    const { start_time, end_time, power_value } = req.body
    if (!start_time || !end_time || !power_value) {
      return res.status(200).json({
        status: false,
        message: "Missing details time range , date , values, days to send",
      });
    }
    const { timeSlot } = await createTimeSlot(req.body);
    if (timeSlot) {
      return res.status(200).json({
        timeSlot,
        message: "Entries feeded successfully",
        status: true,
      });
    } else {
      return res.status(200).json({
        data: [],
        status: false,
        message: "Unable to feed enries",
      });
    }
  } catch (error) {
    console.log(error, "error");
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};
exports.getUpcomingSlots = async (req, res, next) => {
  try {
    const { timeSlots } = await getTomorrowTimeSlots();
    if (timeSlots) {
      return res.status(200).json({
        timeSlots,
        message: "Entries feeded successfully",
        status: true,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "Unable to feed enries",
      });
    }
  } catch (error) {
    console.log(error, "error");
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};
exports.getSlots = async (req, res, next) => {
  try {
    const { startDate, endDate } = req.query

    if (!startDate || !endDate) {
      return res.status(400).json({
        status: false,
        message: "Missing details start date or end date",
      });
    }

    const { timeSlots } = await getTimeSlotsByDateRange(startDate, endDate);
    if (timeSlots) {
      return res.status(200).json({
        timeSlots,
        message: "Entries feeded successfully",
        status: true,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "Unable to feed enries",
      });
    }
  } catch (error) {
    console.log(error, "error");
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};
exports.createBulkSlots = async (req, res, next) => {
  try {
    const { slots } = req.body

    if (!slots || !slots?.length) {
      return res.status(400).json({
        status: false,
        message: "Missing details time slots",
      });
    }

    const { timeSlots } = await createTimeSlots(slots);
    if (timeSlots) {
      return res.status(200).json({
        timeSlots,
        message: "Entries feeded successfully",
        status: true,
      });
    } else {
      return res.status(200).json({
        status: false,
        message: "Unable to feed enries",
      });
    }
  } catch (error) {
    console.log(error, "error");
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};
exports.deleteSlots = async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!id) {
      return res.status(400).json({
        status: false,
        message: "Missing details id",
      });
    }

    await deleteTimeSlot(id);
    return res.status(200).json({
      message: "Entries deleted successfully",
      status: true,
    });

  } catch (error) {
    console.log(error, "error");
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};

exports.getAlerts = async (req, res, next) => {
  try {
    const { configs, page, pageSize, total } = await getConfigs(req);
    return res.status(200).json({
      message: "Entries getting alerts",
      status: true,
      configs,
      page,
      pageSize,
      total
    });

  } catch (error) {
    console.log(error, "error");
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};

exports.updateAlerts = async (req, res, next) => {
  try {
    const { field, displayName, conditionType, value, enabled } = req.body;


    if (!field || !displayName || !conditionType || value === null || value === undefined || !enabled) {
      return res.status(400).json({
        status: false,
        message: "Missing fields field displayName conditionType value enabled",
      });
    }

    const { config } = await updateConfig(req)
    return res.status(200).json({
      message: "Entries updated successfully",
      status: true,
      config
    });

  } catch (error) {
    console.log(error, "error");
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};

exports.addAlerts = async (req, res, next) => {
  try {
    const { field, displayName, conditionType, value, enabled } = req.body;


    if (!field || !displayName || !conditionType || !value || !enabled) {
      return res.status(400).json({
        status: false,
        message: "Missing fields field displayName conditionType value enabled",
      });
    }

    const { config } = await addConfig(req)
    return res.status(200).json({
      message: "Entries added successfully",
      status: true,
      config
    });

  } catch (error) {
    console.log(error, "error");
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};
exports.deleteAlerts = async (req, res, next) => {
  try {
    const { id } = req.params;
    await deleteConfig(id)
    return res.status(200).json({
      message: "Entries deleted successfully",
      status: true,
    });

  } catch (error) {
    console.log(error, "error");
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};


