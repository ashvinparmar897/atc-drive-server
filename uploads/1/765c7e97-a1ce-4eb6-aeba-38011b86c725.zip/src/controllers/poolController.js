const { getPoolTimeSeries, getAllPoolsTimeSeries } = require("../services/influxService");
const { getPoolsRevenue } = require("../services/poolService");

exports.getPoolTimeSeries = async (req, res, next) => {
  try {
    const { macAddress } = req.params;
    const { timeRange = '24h' } = req.query;

    const poolData = await getPoolTimeSeries(macAddress, timeRange);

    return res.status(200).json({
      data: poolData,
      status: true,
    });
  } catch (error) {
    if (!error.statusCode) {
      error.statusCode = 500;
    }
    next(error);
  }
};

exports.getAllPoolsTimeSeries = async (req, res, next) => {
  try {
    const { timeRange = '1d' } = req.query;
    const poolData = await getAllPoolsTimeSeries(timeRange);

    return res.status(200).json({
      poolData,
      status: true,
    });
  } catch (error) {
    if (!error.statusCode) {
      error.statusCode = 500;
    }
    next(error);
  }
};

exports.fetchTotalBTCRevenue = async (req, res, next) => {
  try {
    const revenueData = await getPoolsRevenue();
    return res.status(200).json({
      data: revenueData,
      status: true,
    });
  } catch (error) {
    if (!error.statusCode) {
      error.statusCode = 500;
    }
    next(error);
  }
};
