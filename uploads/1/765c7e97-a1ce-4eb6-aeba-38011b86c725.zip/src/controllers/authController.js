const { register, signin, refresh, requestPassword, reset, getUser, getUsers, updateUser, validate, resendVerificationCode, verifyAndCompleteSignup, initiateSignup, getAllUsersForAdmin } = require('../services/authService');

const signup = async (req, res, next) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) {
            return res.status(400).json({ message: 'Email and password are required' });
        }
        const { accessToken, message, refreshToken, role, userId } = await register(req?.body)
        res.status(201).json({
            message,
            userId,
            accessToken,
            refreshToken,
            role
        });
    } catch (error) {
        if (!error.statusCode) {
            return (error.statusCode = 500);
        }
        next(error);
    }
};

const login = async (req, res, next) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) {
            return res.status(400).json({ message: 'Email and password are required' });
        }
        const { accessToken, message, refreshToken, role, user } = await signin(req.body)
        res.status(200).json({
            message,
            user,
            accessToken,
            refreshToken,
            role
        });
    } catch (error) {
        console.error('Login error:', error);
        if (!error.statusCode) {
            return (error.statusCode = 500);
        }
        next(error);
    }
};
const refreshToken = async (req, res, next) => {
    try {
        const { refreshToken } = req.body;
        if (!refreshToken) {
            return res.status(401).json({ message: 'Refresh token required' });
        }
        const { accessToken, newRefreshToken } = await refresh(req?.body)
        res.status(200).json({
            accessToken,
            refreshToken: newRefreshToken
        });
    } catch (error) {
        console.error('Login error:', error);
        if (!error.statusCode) {
            return (error.statusCode = 500);
        }
        next(error);
    }
};

const requestPasswordReset = async (req, res, next) => {
    try {
        const { email } = req.body;
        if (!email) {
            return res.status(400).json({ message: 'Email is required' });
        }
        const { message } = await requestPassword(req?.body)
        res.status(200).json({ message });
    } catch (error) {
        console.error('Password reset request error:', error);
        if (!error.statusCode) {
            return (error.statusCode = 500);
        }
        next(error);
    }
};
const resetPassword = async (req, res, next) => {
    try {
        const { token, newPassword } = req.body;
        if (!token || !newPassword) {
            return res.status(400).json({ message: 'Token and new password are required' });
        }
        if (newPassword.length < 8) {
            return res.status(400).json({ message: 'Password must be at least 8 characters' });
        }
        const { message } = await reset(req?.body)
        res.status(200).json({
            message
        })
    } catch (error) {
        console.error('Password reset error:', error);
        if (!error.statusCode) {
            return (error.statusCode = 500);
        }
        next(error);
    }
};

const getCurrentUser = async (req, res, next) => {
    try {
        const { user } = await getUser(req?.userId)
        res.status(200).json({
            user
        })
    } catch (error) {
        if (!error.statusCode) {
            return (error.statusCode = 500);
        }
        next(error);
    }
};

const getAllUsers = async (req, res, next) => {
    try {
        const { users, page, pageSize, total } = await getUsers(req)

        if (users) {
            res.status(200).json({ users, page, pageSize, total });
        }
        res.status(404).json({ message: "Users not found" });

    } catch (error) {
        if (!error.statusCode) {
            return (error.statusCode = 500);
        }
        next(error);
    }
};

const updateUserRole = async (req, res, next) => {
    try {
        const { user } = await updateUser(req)
        res.status(200).json({
            message: 'User role updated successfully',
            user: {
                id: user?.id,
                name: user?.name,
                email: user?.email,
                role: user?.role
            }
        });
    } catch (error) {
        if (!error.statusCode) {
            return (error.statusCode = 500);
        }
        next(error);
    }
};

const validateRole = async (req, res, next) => {
    try {
        const { user } = await validate(req.userId)
        res.status(200).json({
            isAdmin: user?.role?.name === 'Admin'
        });
    } catch (error) {
        if (!error.statusCode) {
            return (error.statusCode = 500);
        }
        next(error);
    }
};

const startSignup = async (req, res, next) => {
    try {
        const { email, password, name } = req.body;
        if (!email || !password || !name) {
            return res.status(400).json({ message: 'All fields are required' });
        }

        const { message, email: registeredEmail } = await initiateSignup({ email, password, name });
        res.status(200).json({
            message,
            email: registeredEmail
        });
    } catch (error) {
        next(error);
    }
};

const completeSignup = async (req, res, next) => {
    try {
        const { email, code } = req.body;
        if (!email || !code) {
            return res.status(400).json({ message: 'All fields are required' });
        }

        const {
            message,
            userId,
            accessToken,
            refreshToken,
            role
        } = await verifyAndCompleteSignup({ email, code });

        res.status(200).json({
            message,
            userId,
            accessToken,
            refreshToken,
            role
        });
    } catch (error) {
        next(error);
    }
};

const resendVerification = async (req, res, next) => {
    try {
        const { email } = req.body;
        if (!email) {
            return res.status(400).json({ message: 'Email is required' });
        }
        const { message, email: registeredEmail } = await resendVerificationCode({ email });
        res.status(200).json({
            message,
            email: registeredEmail
        });
    } catch (error) {
        next(error);
    }
};

const getUsersForAdmin = async (req, res, next) => {
    try {
        const { users } = await getAllUsersForAdmin()
        res.status(200).json({
            status: true,
            users
        });
    } catch (error) {
        next(error);
    }
};

module.exports = {
    signup,
    login,
    getCurrentUser,
    getAllUsers,
    updateUserRole,
    refreshToken,
    requestPasswordReset,
    resetPassword,
    validateRole,
    startSignup,
    completeSignup,
    resendVerification,
    getUsersForAdmin
};