const { getMiners, saveThresholdSettings, getThresholdSettings } = require("../services/redisServices");
const { getMinerDetailsById } = require("../services/minerService");
const { calculateDashboardStats, convertTHtoEH } = require("../utils/utils");
const { redisClientRead } = require("../config");
const { getAllMinersTimeSeriesData, getMinerTimeSeriesData } = require("../services/influxService");
const { getPowerUsageSinceMidnightTotal } = require("../services/containerService");

exports.getMinersList = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 10;
    const statusFilter = req.query.status;
    const userId = req?.userId;

    const { miners, totalCount } = await getMiners(page, pageSize, statusFilter, userId);

    if (miners) {
      return res.status(200).json({
        data: {
          miners,
          pagination: {
            total: totalCount,
            page,
            pageSize,
            totalPages: Math.ceil(totalCount / pageSize)
          }
        },
        status: true,
      });
    } else {
      return res.status(200).json({
        data: [],
        status: true,
        message: "Unable to fetch miners",
      });
    }
  } catch (error) {
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};

exports.getCurrentTotalHashrate = async (req, res, next) => {
  try {
    const totalHashrate = await redisClientRead.get('total_hashrate');
    const ehsHashrate = convertTHtoEH(parseFloat(totalHashrate || '0'))
    return res.status(200).json({ data: { totalHashrate: ehsHashrate } })
  } catch (error) {
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};

exports.getMinerDashboardStats = async (req, res, next) => {
  try {
    const userId = req?.userId;
    const userSettings = await redisClientRead.hGetAll(`user:${userId}:settings`);
    const { miners } = await getMiners();
    if (!miners || miners.length === 0) {
      return res.status(200).json({
        data: {
          stats: {
            total: 0,
            onRack: 0,
            normal: 0,
            fault: 0,
            invalid: 0,
            offRack: 0,
            repair: 0,
            offline: 0,
            notWhitelisted: 0,
            zeroHashrate: 0,
            hasboardFault: 0,
            fanFault: 0,
            highTemperature: 0,
            highRejectRate: 0,
          },
        },
        status: true,
        message: 'No miners found',
      });
    }

    const stats = calculateDashboardStats(miners, userSettings);
    return res.status(200).json({
      data: { stats },
      status: true,
    });
  } catch (error) {
    console.error('Error in getMinerDashboardStats:', error);
    if (!error.statusCode) {
      error.statusCode = 500;
    }
    next(error);
  }
};

exports.getMinerDetail = async (req, res, next) => {
  try {
    const { ip } = req.params;

    const details = await getMinerDetailsById(ip);
    if (details?.miner && details?.pools && details?.stats) {
      return res.status(200).json({
        data: {
          details,
        },
        status: true,
      });
    } else {
      return res.status(200).json({
        data: [],
        status: true,
        message: "Unable to fetch miner",
      });
    }
  } catch (error) {
    if (!error?.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};
exports.getTimeSeries = async (req, res, next) => {
  try {
    const { ip, timeRange } = req.query;

    if (!ip) {
      res.status(200).json({
        data: [],
        status: false,
        message: "Missing Details: IP ADDRESS",
      });
    }
    const { hashrate, temp1, temp2, temp0 } = await getMinerTimeSeriesData(ip, timeRange);

    if (hashrate && temp0 && temp2 && temp0) {
      return res.status(200).json({
        data: {
          hashrate,
          temp0,
          temp1,
          temp2,
        },
        status: true,
      });
    } else {
      return res.status(200).json({
        data: [],
        status: true,
        message: "Unable to fetch hashrate or temperature",
      });
    }
  } catch (error) {
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};
exports.getAllTimeSeries = async (req, res, next) => {
  try {
    const { timeRange } = req.query;
    const minersData = await getAllMinersTimeSeriesData(timeRange);
    if (minersData && minersData.length > 0) {
      return res.status(200).json({
        data: minersData,
        status: true,
      });
    } else {
      return res.status(200).json({
        data: [],
        status: true,
        message: "Unable to fetch hashrate data for any miners",
      });
    }
  } catch (error) {
    if (!error.statusCode) {
      error.statusCode = 500;
    }
    next(error);
  }
};
exports.saveThreshold = async (req, res, next) => {
  try {
    const { fanFaultThreshold, highTempThreshold, highRejectRateThreshold } = req.body;

    await saveThresholdSettings(req?.userId, {
      fanFaultThreshold,
      highTempThreshold,
      highRejectRateThreshold
    });

    res.status(200).json({ status: true });
  } catch (error) {
    if (!error?.statusCode) {
      error.statusCode = 500;
    }
    next(error);
  }
};

exports.getThreshold = async (req, res, next) => {
  try {
    const { threshold } = await getThresholdSettings(req?.userId);
    if (threshold) {
      res.status(200).json({ data: { threshold }, status: true });
    } else {
      res.status(200).json({ data: { threshold: {} }, status: true });
    }
  } catch (error) {
    console.log(error);
    if (!error?.statusCode) {
      error.statusCode = 500;
    }
    next(error);
  }
};
exports.getPowerConsumption = async (req, res, next) => {
  try {
    const { energyMWhSinceMidnight } = await getPowerUsageSinceMidnightTotal();
    if (energyMWhSinceMidnight) {
      return res.status(200).json({
        data: {
          energyMWhSinceMidnight,
        },
        status: true,
      });
    } else {
      return res.status(200).json({
        data: [],
        status: false,
        message: "Unable to fetch power consumption",
      });
    }
  } catch (error) {
    console.log(error, "error");
    if (!error.statusCode) {
      return (error.statusCode = 500);
    }
    next(error);
  }
};