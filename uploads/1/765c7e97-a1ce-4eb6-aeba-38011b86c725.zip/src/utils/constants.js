module.exports = {
  MINER_STATUSES: {
    ONLINE: 'online',
    OFFLINE: 'offline',
    NORMAL: 'normal',
    FAULT: 'fault',
    INVALID: 'invalid',
    OFF_RACK: 'off_rack',
    REPAIR: 'repair',
    NOT_WHITELISTED: 'not_whitelisted',
    ZERO_HASHRATE: 'zero_hashrate',
    HASHBOARD_FAULT: 'hashboard_fault',
    FAN_FAULT: 'fan_fault',
    HIGH_TEMPERATURE: 'high_temperature',
    HIGH_REJECT_RATE: 'high_reject_rate',
  },
  DEFAULT_STATUS_CONFIG: {
    highTempThreshold: 90,
    highRejectRateThreshold: 3,
    lowHashrateThreshold: 10,
    offlineThresholdHours: 24,
    notWhitelistedThresholdHours: 48,
  },

  graphTimeRanges: {
    "24h": { flux: "24h", interval: "10m", bucket: process.env.INFLUXDB_HASHRATE_10_MIN_BUCKET },
    "7d": { flux: "7d", interval: "1h", bucket: process.env.INFLUXDB_HASHRATE_HOURLY_BUCKET },
    "30d": { flux: "30d", interval: "5h", bucket: process.env.INFLUXDB_HASHRATE_5_HOURLY_BUCKET },
    "60d": { flux: "60d", interval: "12h", bucket: process.env.INFLUXDB_HASHRATE_12_HOURLY_BUCKET },
    "180d": { flux: "180d", interval: "1d", bucket: process.env.INFLUXDB_HASHRATE_DAILY_BUCKET },
  },
};