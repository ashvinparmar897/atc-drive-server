const axios = require("axios");
const nodemailer = require('nodemailer')
const AWS = require('aws-sdk');

const BINANCE_CONVERSION_RATE_API_URL =
  process.env.BINANCE_CONVERSION_RATE_API_URL;

// const POWER_KEYS = ["1总视在功率", "4总视在功率", "5总视在功率", "6总视在功率"];
const TIMEZONE = "Europe/Helsinki";
const POWER_KEYS = ['1_apparent_power', '4_apparent_power', '5_apparent_power', '6_apparent_power'];

const FREQUENCY_REPORT_HOUR = 6
const DAILY_REPORT_HOUR = 7
const VERIFICATION_CODE_EXPIRY_MINUTES = 10;


const JWT_SECRET = process.env.JWT_SECRET;
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET;
const JWT_ACCESS_EXPIRES_IN = process.env.JWT_ACCESS_EXPIRES_IN;
const JWT_REFRESH_EXPIRES_IN = process.env.JWT_REFRESH_EXPIRES_IN;

const moment = require("moment-timezone");
const { MINER_STATUSES, DEFAULT_STATUS_CONFIG } = require("./constants");
// const { METRIC_TRANSLATIONS } = require("../constants/constants");
const ses = new AWS.SES({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_SES_REGION || 'us-east-1'
});

function getCurrentTime() {
  return moment().tz(TIMEZONE).format();
}

function parseAndValidateMessage(messageContent) {
  try {
    // const jsonData = messageContent.slice(messageContent.indexOf("{"));
    const parsed = JSON.parse(messageContent);
    if (!parsed.data || typeof parsed.data !== 'object') {
      throw new Error("Invalid message format - missing data object");
    }
    return parsed;
  } catch (error) {
    console.error("Message validation error:", error.message);
    return null;
  }
}

function getYesterdayUTCDateString() {
  const now = new Date();
  return new Date(Date.UTC(
    now.getUTCFullYear(),
    now.getUTCMonth(),
    now.getUTCDate() - 1,
    0, 0, 0
  )).toISOString().split("T")[0];
}


function hasAllPowerKeys(cruxData) {
  return POWER_KEYS.every((key) => cruxData.some((item) => item?.name === key));
}

const filterDataAccordingToCurrentTimeZone = (data) => {
  const now = new Date();

  // Format current time to match the API timestamp (rounding to minutes)
  const nowUTC = now.toISOString().slice(0, 16) + ":00Z";

  // Find exact match
  const exactMatch = data.find((item) => item.timestamp === nowUTC);

  if (exactMatch) return exactMatch;

  // If no exact match, find the closest match
  return data.reduce((closest, item) => {
    const itemTime = new Date(item.timestamp).getTime();
    const closestTime = new Date(closest.timestamp).getTime();
    return Math.abs(itemTime - now.getTime()) <
      Math.abs(closestTime - now.getTime())
      ? item
      : closest;
  });
};

const getConvertedDataInEUR = async () => {
  const exchangeRateResponse = await axios.get(
    `${BINANCE_CONVERSION_RATE_API_URL}`
  );

  if (!exchangeRateResponse?.data || !exchangeRateResponse?.data?.price) {
    return null;
  }

  const conversionRate = Number(1 / exchangeRateResponse?.data?.price).toFixed(
    4
  );

  return { conversionRate };
};

function extractMetrics(cruxData) {
  const metrics = {};

  // cruxData.forEach((item) => {
  //   const meterMatch = item.name.match(/^(\d)(电压|电流)L([123])$/);
  //   if (meterMatch) {
  //     const [, meterNumber, typeChinese, lineNumber] = meterMatch;
  //     const type = typeChinese === "电压" ? "voltage" : "current";
  //     const meterKey = `electric_meter${meterNumber}_${type}_l${lineNumber}`;
  //     metrics[meterKey] = parseFloat(item.value);
  //     return;
  //   }

  //   if (item.name.match(/^\dKWh$/)) {
  //     const meterNumber = item?.name?.charAt(0);
  //     metrics[`electric_meter${meterNumber}_kwh`] = parseFloat(item.value);
  //     return;
  //   }

  //   const translatedName = METRIC_TRANSLATIONS[item?.name];
  //   if (translatedName) {
  //     metrics[translatedName] = parseFloat(item?.value);
  //   }
  // });
  const dataEntries = Array.isArray(cruxData)
    ? cruxData
    : Object.entries(cruxData).map(([name, value]) => ({ name, value }));

  dataEntries.forEach((item) => {
    const meterMatch = item.name.match(/^meter_(\d)_(voltage|current)_l(\d)$/);
    if (meterMatch) {
      const [, meterNumber, type, lineNumber] = meterMatch;
      const meterKey = `electric_meter${meterNumber}_${type}_l${lineNumber}`;
      metrics[meterKey] = parseFloat(item.value);
      return;
    }
    if (item.name === "supply_return_hydraulic_diff") {
      metrics['hydraulic_pressure_diff'] = parseFloat(item.value);
    }

    if (item.name === "filter_diff") {
      metrics['filter_pressure_diff'] = parseFloat(item.value);
    }

    if (item.name === "water_immersion_alarm_1") {
      metrics['water_immersion_alarm_1'] = parseFloat(item.value);
    }

    if (item.name === "water_immersion_alarm_2") {
      metrics['water_immersion_alarm_2'] = parseFloat(item.value);
    }

    if (item.name === "spare_temp_t3") {
      metrics['temperature_t3'] = parseFloat(item.value);
    }

    if (item.name === "spare_temp_t4") {
      metrics['temperature_t4'] = parseFloat(item.value);
    }

    if (item.name === "absolute_filter_diff") {
      metrics['abs_filter_pressure_diff'] = parseFloat(item.value);
    }

    // Handle other metrics
    // const translatedName = METRIC_TRANSLATIONS[item.name] || item.name;
    if (item?.value !== null && item.value !== undefined) {
      metrics[item?.name] = parseFloat(item.value);
    }
  });

  return metrics;
}

function processLogs(logData) {
  const stats = logData.data.STATS[1];
  const info = logData.data.STATS[0];

  const convertToTHS = (value) => {
    if (stats.rate_unit === "GH") return value / 1000;
    return value;
  };

  return {
    ip: logData.ip,
    mac_address: logData.mac_address,
    miner_info: {
      type: info.Type,
      model: "Antminer S21 XP Hyd.",
      version: info.Miner,
      compile_time: info.CompileTime,
      miner_id: stats?.miner_id || '',
    },
    hashrate: {
      current: convertToTHS(stats["GHS 5s"]),
      average: convertToTHS(stats["GHS av"]),
      rate_30m: convertToTHS(stats.rate_30m),
      unit: "TH",
    },
    temperature: {
      values: [stats.temp2_1, stats.temp2_2, stats.temp2_3].filter(
        (temp) => temp !== undefined
      ),
      max: Math.max(stats.temp2_1 || 0, stats.temp2_2 || 0, stats.temp2_3 || 0),
    },
    fans: {
      values: [stats.fan1, stats.fan2, stats.fan3, stats.fan4].filter(
        (fan) => fan !== undefined
      ),
    },
    frequency: {
      values: [stats.freq1, stats.freq2, stats.freq3, stats.freq4].filter(
        (freq) => freq !== undefined
      ),
      average: stats.total_freqavg,
    },
    chains: {
      active: stats.total_acn,
      details: [1, 2, 3, 4].map((i) => ({
        id: i,
        active: stats[`chain_acn${i}`] || 0,
        status: stats[`chain_acs${i}`] || "",
      })),
    },
    timestamp: new Date(),
  };
}

function combineData(logData, poolData) {
  const processedLog = processLogs(logData);
  const poolInfo = JSON.parse(poolData.data.replace(/\n/g, ""));

  return {
    ...processedLog,
    pool_info: {
      pools: poolInfo.POOLS.map((pool) => ({
        url: pool.url,
        user: pool.user,
        status: pool.status,
        priority: pool.priority,
        accepted: pool.accepted,
        rejected: pool.rejected,
        stale: pool.stale,
        difficulty: pool.diff,
      })),
      active_pool: poolInfo.POOLS.find((pool) => pool.status === "Alive")?.url,
    },
  };
}

function validateFloat(value) {
  if (value === null || value === undefined || Number.isNaN(value)) {
    return 0;
  }
  return parseFloat(value);
}

function validateFloatArray(values) {
  if (!Array.isArray(values)) return [];
  return values.map(validateFloat);
}

function mergeDeviceData(existingData, newData) {
  if (!existingData) return newData;

  const merged = { ...existingData };

  if (newData.cruxData) {
    merged.cruxData = merged?.cruxData || [];

    const existingValues = new Map();
    merged?.cruxData?.forEach((item) => {
      existingValues.set(item?.name, item);
    });

    newData?.cruxData?.forEach((newItem) => {
      if (
        newItem?.value !== null &&
        newItem?.value !== undefined &&
        newItem?.value !== ""
      ) {
        existingValues.set(newItem?.name, newItem);
      }
    });

    merged.cruxData = Array.from(existingValues?.values());
  }

  Object.keys(newData).forEach((key) => {
    if (
      key !== "cruxData" &&
      newData[key] !== null &&
      newData[key] !== undefined
    ) {
      merged[key] = newData[key];
    }
  });

  return merged;
}

const transporter = nodemailer.createTransport({
  service: process.env.EMAIL_SERVICE || 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

const ipToContainerMap = {
  '1': 'Container 3',
  '2': 'Container 1',
  '3': 'Container 2',
  '4': 'Container 4',
  '5': 'Container 5',
  '6': 'Container 6',
  '7': 'Container 7',
  '8': 'Container 8',
  '9': 'Container 9',
  '10': 'Container 10',
  '11': 'Container 11',
  '12': 'Container 12',
  '13': 'Container 13',
  '14': 'Container 14',
  '15': 'Container 15',
  '16': 'Container 16',
  '17': 'Container 17',
  '18': 'Container 18',
  '19': 'Container 19',
  '20': 'Container 20',
  '21': 'Container 21',
  '22': 'Container 22',
  '23': 'Container 23',
  '24': 'Container 24',
  '25': 'Container 25',
  '26': 'Container 26',
};

const generateVerificationCode = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

function convertTHtoEH(thValue, decimals = 2) {
  const ehValue = thValue / 1e6;
  const rounded = Number(ehValue.toFixed(decimals));
  return rounded;
}
function convertTHtoPH(thValue, decimals = 2) {
  const phValue = thValue / 1e3;
  const rounded = Number(phValue.toFixed(decimals));
  return rounded;
}

const sendVerificationEmail = async (email, code) => {
  const params = {
    Destination: {
      ToAddresses: [email]
    },
    Message: {
      Body: {
        Html: {
          Charset: "UTF-8",
          Data: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #213654;">Email Verification</h2>
              <p>Thank you for signing up. Here's your verification code:</p>
              <div style="margin: 20px 0; font-size: 24px; font-weight: bold; letter-spacing: 2px;">
                ${code}
              </div>
              <p>This code will expire in 10 minutes.</p>
              <p style="color: #666; font-size: 12px; margin-top: 30px;">
                © ${new Date().getFullYear()} Bitcoin Mining. All rights reserved.
              </p>
            </div>
          `
        },
        Text: {
          Charset: "UTF-8",
          Data: `Your verification code is: ${code}\n\nThis code will expire in 10 minutes.`
        }
      },
      Subject: {
        Charset: "UTF-8",
        Data: "Email Verification Code"
      }
    },
    Source: `Bitcoin Mining <${process.env.SES_FROM_EMAIL}>`,
  };

  await ses.sendEmail(params).promise();
};

const sendAlertEmailToAdmin = async (subject, htmlMessage, textMessage = '') => {
  const params = {
    Destination: {
      ToAddresses: ['vaibhav.kotadiya@bilttek.com'],
    },
    Message: {
      Body: {
        Html: {
          Charset: "UTF-8",
          Data: htmlMessage,
        },
        Text: {
          Charset: "UTF-8",
          Data: textMessage || htmlMessage.replace(/<[^>]+>/g, ''), // fallback to text if not provided
        }
      },
      Subject: {
        Charset: "UTF-8",
        Data: subject,
      }
    },
    Source: `Monitoring Alert <${process.env.SES_FROM_EMAIL}>`,
  };

  try {
    await ses.sendEmail(params).promise();
    console.log("🚨 Alert email sent to admin.");
  } catch (error) {
    console.error("❌ Failed to send alert email:", error);
  }
};

function chunkArray(array, size) {
  const chunks = [];
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size));
  }
  return chunks;
}

function tryParseJson(str) {
  if (typeof str !== 'string' || str.trim() === '' || str === 'null') return null;
  try {
    return JSON.parse(str);
  } catch {
    return null;
  }
}

function parseFloatOrNull(value) {
  if (value === null || value === undefined) return null;
  if (typeof value === 'number') return value;
  if (typeof value !== 'string') return null;

  const trimmed = value.trim();
  if (trimmed === '' || trimmed.toLowerCase() === 'null') return null;

  const num = parseFloat(trimmed);
  return isNaN(num) ? null : num;
}

function parseFloatArray(value) {
  const parsed = tryParseJson(value);
  if (!Array.isArray(parsed)) return [];
  return parsed
    .map(v => parseFloatOrNull(v))
    .filter(v => typeof v === 'number');
}

function parseStatus(value) {
  const valid = ['online', 'offline', 'warning'];
  return valid.includes(value) ? value : 'online';
}

function formatMac(mac) {
  return typeof mac === 'string' ? mac.toUpperCase() : null;
}


const calculateDashboardStats = (miners, userSettings) => {
  const stats = {
    total: miners.length,
    onRack: 0,
    normal: 0,
    fault: 0,
    invalid: 0,
    offRack: 0,
    repair: 0,
    offline: 0,
    notWhitelisted: 0,
    zeroHashrate: 0,
    hasboardFault: 0,
    fanFault: 0,
    highTemperature: 0,
    highRejectRate: 0,
  };

  miners?.forEach(miner => {
    const status = determineMinerStatus(miner, userSettings);
    if (status === MINER_STATUSES.NORMAL) stats.normal++;
    if (status === MINER_STATUSES.OFFLINE) stats.offline++;
    if (status === MINER_STATUSES.ZERO_HASHRATE) stats.zeroHashrate++;
    if (status === MINER_STATUSES.FAN_FAULT) stats.fanFault++;
    if (status === MINER_STATUSES.HIGH_TEMPERATURE) stats.highTemperature++;
    if (status === MINER_STATUSES.HIGH_REJECT_RATE) stats.highRejectRate++;

    stats.invalid = stats.offline + stats.notWhitelisted + stats.zeroHashrate;
    stats.fault = stats.hasboardFault + stats.fanFault + stats.highTemperature + stats.highRejectRate;
    stats.onRack = stats.total;
  });

  return stats;
};

const determineMinerStatus = (miner, userSettings) => {
  const config = DEFAULT_STATUS_CONFIG;
  const highTempThreshold = parseInt(userSettings.highTempThreshold) || DEFAULT_STATUS_CONFIG.highTempThreshold;
  const highRejectRateThreshold = parseFloat(userSettings.highRejectRateThreshold) || DEFAULT_STATUS_CONFIG.highRejectRateThreshold;
  const now = new Date();
  const lastUpdated = new Date(miner.last_updated);
  const hoursSinceUpdate = (now.getTime() - lastUpdated.getTime()) / (1000 * 60 * 60);

  if (
    hoursSinceUpdate > config.offlineThresholdHours
  ) {
    return MINER_STATUSES.OFFLINE;
  }

  if (!miner.hashrate || miner.hashrate === 0 || miner.hashrate === '0') {
    return MINER_STATUSES.ZERO_HASHRATE;
  }

  // if (miner.fans?.some(fan => !fan)) {
  //   return MINER_STATUSES.FAN_FAULT;
  // }

  if (miner.temp_max >= highTempThreshold) {
    return MINER_STATUSES.HIGH_TEMPERATURE;
  }
  const totalAccepted = miner.pools?.reduce((sum, pool) => sum + (pool.accepted || 0), 0) || 0;
  const totalRejected = miner.pools?.reduce((sum, pool) => sum + (pool.rejected || 0), 0) || 0;
  const rejectRate = totalAccepted > 0 ? (totalRejected / totalAccepted) * 100 : 0;
  if (rejectRate > highRejectRateThreshold) {
    return MINER_STATUSES.HIGH_REJECT_RATE;
  }
  return MINER_STATUSES.NORMAL;
};


function buildMinerFromData(key, data) {
  const parse = (field) => {
    try { return data[field] ? JSON.parse(data[field]) : []; }
    catch { return []; }
  };

  return {
    mac_address: key.split(':')[1],
    ip: data?.ip,
    container_name: data.container_name,
    type: data?.type || '',
    model: data?.model || '',
    workingMode: data?.workingMode || '',
    hashrate: data?.hashrate || '0',
    avg_hashrate: data?.avg_hashrate || '0',
    temp_max: data?.temp_max || '0',
    fans: parse('fans'),
    hashrates: parse('hashrates'),
    temperatures: parse('temperatures'),
    frequencies: parse('frequencies'),
    active_chains: parse('active_chains'),
    active_chains_info: parse('active_chains_info'),
    pools: parse('pools'),
    last_updated: new Date(parseInt(data?.last_updated || Date.now())).toISOString(),
    status: 'unknown'
  };
}

const intervalMapping = {
  '1d': '5m',
  '7d': '1h',
  '30d': '1h',
  '180d': '5h',
};

function getAggregationInterval(timeRange = '7d') {
  return intervalMapping[timeRange] || '1h';
}

function parseDuration(str) {
  const unit = str.slice(-1);
  const num = parseInt(str.slice(0, -1));
  const multipliers = { m: 60000, h: 3600000, d: 86400000 };
  return num * multipliers[unit];
}

function getLiveStart(now, interval) {
  const unit = interval.slice(-1);
  const num = parseInt(interval.slice(0, -1));
  const ms = { m: 60000, h: 3600000, d: 86400000 }[unit] * num;
  return new Date(Math.floor(now.getTime() / ms) * ms);
}


module.exports = {
  filterDataAccordingToCurrentTimeZone,
  getConvertedDataInEUR,
  buildMinerFromData,
  getCurrentTime,
  parseAndValidateMessage,
  hasAllPowerKeys,
  POWER_KEYS,
  processLogs,
  combineData,
  validateFloat,
  validateFloatArray,
  extractMetrics,
  mergeDeviceData,
  FREQUENCY_REPORT_HOUR, DAILY_REPORT_HOUR,
  TIMEZONE,
  JWT_ACCESS_EXPIRES_IN,
  JWT_REFRESH_EXPIRES_IN,
  JWT_REFRESH_SECRET,
  JWT_SECRET,
  transporter,
  ipToContainerMap,
  ses,
  generateVerificationCode,
  sendVerificationEmail,
  VERIFICATION_CODE_EXPIRY_MINUTES,
  sendAlertEmailToAdmin,
  chunkArray,
  calculateDashboardStats,
  determineMinerStatus,
  convertTHtoEH,
  convertTHtoPH,
  getAggregationInterval,
  tryParseJson,
  getYesterdayUTCDateString,
  parseDuration,
  getLiveStart,
  formatMac,
  parseFloatOrNull,
  parseFloatArray,
  parseStatus
};
