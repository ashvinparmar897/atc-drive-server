'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('miner_pools', {
      id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      url: {
        type: Sequelize.STRING(255),
        allowNull: false,
      },
      worker: {
        type: Sequelize.STRING(255),
        allowNull: false,
      },
      status: {
        type: Sequelize.ENUM("Alive", "Dead", "Disabled"),
        allowNull: false,
      },
      priority: {
        type: Sequelize.INTEGER,
        allowNull: false,
      },
      accepted: {
        type: Sequelize.INTEGER,
        defaultValue: 0,
      },
      rejected: {
        type: Sequelize.INTEGER,
        defaultValue: 0,
      },
      miner_mac: {
        type: Sequelize.STRING(50),
        allowNull: false,
        references: {
          model: 'miners',
          key: 'mac_address',
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE',
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.fn("NOW"),
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.fn("NOW"),
      },
    });

    await queryInterface.addIndex('miner_pools', ['miner_mac']);
  },

  down: async (queryInterface) => {
    await queryInterface.dropTable('miner_pools');
  },
};
