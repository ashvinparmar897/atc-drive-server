'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('miner_stats', {
      id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      hashrate_current: {
        type: Sequelize.FLOAT,
      },
      hashrate_average: {
        type: Sequelize.FLOAT,
      },
      hashrate_30m: {
        type: Sequelize.FLOAT,
      },
      temperature_values: {
        type: Sequelize.ARRAY(Sequelize.FLOAT),
        defaultValue: [],
      },
      temperature_max: {
        type: Sequelize.FLOAT,
      },
      fan_speeds: {
        type: Sequelize.ARRAY(Sequelize.FLOAT),
        defaultValue: [],
      },
      frequencies: {
        type: Sequelize.ARRAY(Sequelize.FLOAT),
        defaultValue: [],
      },
      hashrates: {
        type: Sequelize.ARRAY(Sequelize.FLOAT),
        defaultValue: [],
      },
      frequency_avg: {
        type: Sequelize.FLOAT,
      },
      active_chains: {
        type: Sequelize.ARRAY(Sequelize.FLOAT),
        defaultValue: [],
      },
      active_chains_info: {
        type: Sequelize.JSON,
        defaultValue: null,
      },
      miner_mac: {
        type: Sequelize.STRING(17),
        allowNull: false,
        unique: true,
        references: {
          model: 'miners',
          key: 'mac_address',
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE',
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.fn("NOW"),
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.fn("NOW"),
      },
    });

    await queryInterface.addIndex('miner_stats', ['miner_mac']);
    await queryInterface.addIndex('miner_stats', ['created_at']);
  },

  down: async (queryInterface) => {
    await queryInterface.dropTable('miner_stats');
  },
};
