// Updated migration file
'use strict';

module.exports = {
    up: async (queryInterface, Sequelize) => {
        await queryInterface.createTable('container_hourly_power', {
            id: {
                type: Sequelize.INTEGER,
                autoIncrement: true,
                primaryKey: true,
                allowNull: false,
            },
            date: {
                type: Sequelize.DATEONLY,
                allowNull: false,
            },
            max_power: {
                type: Sequelize.DECIMAL(10, 2),
                allowNull: false,
            },
            is_sent: {
                type: Sequelize.BOOLEAN,
                defaultValue: false,
                allowNull: false,
            },
            sent_at: {
                type: Sequelize.DATE,
                allowNull: true,
            },
            createdAt: {
                type: Sequelize.DATE,
                allowNull: false,
                defaultValue: Sequelize.fn('NOW'),
            },
            updatedAt: {
                type: Sequelize.DATE,
                allowNull: false,
                defaultValue: Sequelize.fn('NOW'),
            },
        });

        await queryInterface.sequelize.query(`
            DO $$
            BEGIN
              IF NOT EXISTS (
                SELECT 1
                FROM pg_indexes
                WHERE tablename = 'container_hourly_power'
                  AND indexname = 'unique_date_hour_index'
              ) THEN
                CREATE UNIQUE INDEX unique_date_hour_index
                ON container_hourly_power (date);
              END IF;
            END$$;
          `);
    },

    down: async (queryInterface, Sequelize) => {
        await queryInterface.dropTable('container_hourly_power');
    },
};