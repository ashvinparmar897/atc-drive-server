'use strict';

/** @type {import('sequelize-cli').Migration} */

module.exports = {
  up: async (queryInterface) => {
    await queryInterface.renameColumn('pools', 'createdAt', 'created_at');
    await queryInterface.renameColumn('pools', 'updatedAt', 'updated_at');
  },

  down: async (queryInterface) => {
    await queryInterface.renameColumn('pools', 'created_at', 'createdAt');
    await queryInterface.renameColumn('pools', 'updated_at', 'updatedAt');
  },
};
