// migrations/XXXXXX-simplify-checklist-structure.js
module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Add content column to checklists table
    await queryInterface.addColumn('checklists', 'content', {
      type: Sequelize.JSONB,
      allowNull: true
    });

    // Add content and updated_by columns to checklist_responses table
    await queryInterface.addColumn('checklist_responses', 'content', {
      type: Sequelize.JSONB,
      allowNull: true
    });
    await queryInterface.addColumn('checklist_responses', 'updated_by', {
      type: Sequelize.INTEGER,
      allowNull: true,
      references: {
        model: 'users',
        key: 'id'
      }
    });

    // Migrate existing data to new structure
    const [checklists] = await queryInterface.sequelize.query(
      "SELECT * FROM checklists"
    );

    for (const checklist of checklists) {
      // Get all sections and questions for this checklist
      const [sections] = await queryInterface.sequelize.query(`
        SELECT cs.*, 
          (SELECT json_agg(
            json_build_object(
              'id', cq.id,
              'question_text', cq.question_text,
              'order', cq.order,
              'created_at', cq.created_at,
              'updated_at', cq.updated_at
            )
          ) FROM checklist_questions cq WHERE cq.section_id = cs.id) as questions
        FROM checklist_sections cs
        WHERE cs.checklist_id = ${checklist.id}
        ORDER BY cs.order
      `);

      // Update checklist with content
      await queryInterface.sequelize.query(`
        UPDATE checklists 
        SET content = :content
        WHERE id = ${checklist.id}
      `, {
        replacements: {
          content: JSON.stringify(sections)
        }
      });

      // Get all responses for this checklist
      const [responses] = await queryInterface.sequelize.query(`
        SELECT * FROM checklist_responses WHERE checklist_id = ${checklist.id}
      `);

      for (const response of responses) {
        // Get all answers for this response
        const [answers] = await queryInterface.sequelize.query(`
          SELECT ca.*, cq.section_id
          FROM checklist_answers ca
          JOIN checklist_questions cq ON ca.question_id = cq.id
          WHERE ca.response_id = ${response.id}
        `);

        // Reconstruct the content structure with answers
        const responseContent = sections.map(section => {
          const sectionAnswers = answers.filter(a => a.section_id === section.id);
          const questions = section.questions.map(question => {
            const answer = sectionAnswers.find(a => a.question_id === question.id);
            return {
              ...question,
              is_checked: answer ? answer.is_checked : false,
              comment: answer ? answer.comment : null,
              updated_by: answer ? answer.updated_by : null
            };
          });
          return {
            ...section,
            questions
          };
        });

        // Update response with content
        await queryInterface.sequelize.query(`
          UPDATE checklist_responses 
          SET content = :content
          WHERE id = ${response.id}
        `, {
          replacements: {
            content: JSON.stringify(responseContent)
          }
        });
      }
    }

    // Drop old tables
    await queryInterface.dropTable('checklist_answers');
    await queryInterface.dropTable('checklist_questions');
    await queryInterface.dropTable('checklist_sections');
  },

  down: async (queryInterface) => {
    // Recreate old tables (implementation would be similar to original migration)
    // Note: This is simplified - in a real scenario you'd need to reconstruct the original structure

    // Remove added columns
    await queryInterface.removeColumn('checklists', 'content');
    await queryInterface.removeColumn('checklist_responses', 'content');
    await queryInterface.removeColumn('checklist_responses', 'updated_by');
  }
};