'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.addColumn('ip_ranges', 'miner_manufacturer',{
        type: Sequelize.STRING,
        allowNull: true
      });
  },

  async down(queryInterface) {
    await queryInterface.removeColumn('ip_ranges', 'miner_manufacturer');
  }
};
