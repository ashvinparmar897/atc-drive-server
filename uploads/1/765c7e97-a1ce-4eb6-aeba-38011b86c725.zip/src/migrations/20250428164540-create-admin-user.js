// migrations/YYYYMMDDHHMMSS-create-admin-user.js
'use strict';
const bcrypt = require('bcryptjs');

module.exports = {
  async up(queryInterface, Sequelize) {
    // Find the Admin role
    const [role] = await queryInterface.sequelize.query(
      'SELECT id FROM user_roles WHERE name = ? LIMIT 1',
      { replacements: ['Admin'], type: Sequelize.QueryTypes.SELECT }
    );

    if (role && role.id) {
      await queryInterface.bulkInsert('users', [{
        name: 'Admin',
        email: 'admin@example.com',
        password: await bcrypt.hash('admin123', 12),
        role_id: role.id,
        created_at: new Date(),
        updated_at: new Date()
      }]);
    }
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('users', { email: 'admin@example.com' });
  }
};