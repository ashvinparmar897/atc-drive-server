'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface) {
    await queryInterface.bulkInsert('alert_configs', [
      {
        field: 'water_immersion_alarm_1',
        displayName: 'Water Immersion Alarm 1',
        conditionType: 'equals',
        value: 1.00,
        enabled: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        field: 'water_immersion_alarm_2',
        displayName: 'Water Immersion Alarm 2',
        conditionType: 'equals',
        value: 1.00,
        enabled: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      }
    ], {});
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('alert_configs', {
      field: {
        [Sequelize.Op.in]: ['water_immersion_alarm_1', 'water_immersion_alarm_2']
      }
    });
  }
};
