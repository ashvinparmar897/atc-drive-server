'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.addColumn('container_metrics', 'water_immersion_alarm_1', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    });

    await queryInterface.addColumn('container_metrics', 'water_immersion_alarm_2', {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null,
    });
  },

  async down(queryInterface) {
    await queryInterface.removeColumn('container_metrics', 'water_immersion_alarm_1');
    await queryInterface.removeColumn('container_metrics', 'water_immersion_alarm_2');
  }
};
