// In file: migrations/YYYYMMDDHHMMSS-create-container-metrics.js
'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('container_metrics', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      container_name: {
        type: Sequelize.STRING(50),
        allowNull: false,
        unique: true,
      },
      temperature: Sequelize.DECIMAL(5, 1),
      humidity: Sequelize.DECIMAL(5, 1),
      pressure_p1: Sequelize.DECIMAL(5, 1),
      pressure_p2: Sequelize.DECIMAL(5, 1),
      pressure_p3: Sequelize.DECIMAL(5, 1),
      pressure_p4: Sequelize.DECIMAL(5, 1),
      pressure_p5: Sequelize.DECIMAL(5, 1),
      hydraulic_pressure_diff: Sequelize.DECIMAL(5, 1),
      filter_pressure_diff: Sequelize.DECIMAL(5, 1),
      temperature_t1: Sequelize.DECIMAL(5, 1),
      temperature_t2: Sequelize.DECIMAL(5, 1),
      temperature_t3: Sequelize.DECIMAL(5, 1),
      temperature_t4: Sequelize.DECIMAL(5, 1),
      frequency: Sequelize.DECIMAL(5, 2),
      inverter_status: Sequelize.INTEGER,
      abs_filter_pressure_diff: Sequelize.DECIMAL(5, 1),
      total_power: Sequelize.DECIMAL(8, 1),
      updated_at: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW,
      },
      // Dynamically generate electric_meterX_voltage_lY / current_lY
      ...(() => {
        const fields = {};
        for (let meter = 1; meter <= 6; meter++) {
          ['voltage', 'current'].forEach(type => {
            [1, 2, 3].forEach(line => {
              fields[`electric_meter${meter}_${type}_l${line}`] = {
                type: Sequelize.DECIMAL(6, 1)
              };
            });
          });
        }
        return fields;
      })()
    });
  },

  down: async (queryInterface) => {
    await queryInterface.dropTable('container_metrics');
  }
};