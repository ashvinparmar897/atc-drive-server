'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('miners', {
      id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      mac_address: {
        type: Sequelize.STRING(50),
        allowNull: false,
        unique: true,
      },
      ip: {
        type: Sequelize.STRING(50),
      },
      type: {
        type: Sequelize.STRING(50),
        allowNull: false,
      },
      model: {
        type: Sequelize.STRING(50),
      },
      version: {
        type: Sequelize.STRING(50),
      },
      compile_time: {
        type: Sequelize.STRING(100),
      },
      miner_id: {
        type: Sequelize.STRING(50),
      },
      agent_id: {
        type: Sequelize.STRING(50),
      },
      status: {
        type: Sequelize.ENUM("online", "offline", "warning"),
        defaultValue: "online",
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.fn("NOW"),
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.fn("NOW"),
      },
    });

    await queryInterface.addIndex('miners', ['ip']);
    await queryInterface.addIndex('miners', ['miner_id']);
    await queryInterface.addIndex('miners', ['status']);
  },

  down: async (queryInterface) => {
    await queryInterface.dropTable('miners');
  },
};
