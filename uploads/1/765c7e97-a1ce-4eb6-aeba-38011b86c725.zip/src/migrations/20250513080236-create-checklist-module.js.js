// migrations/XXXXXX-create-checklist-module.js

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('checklists', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      name: {
        type: Sequelize.STRING,
        allowNull: false
      },
      frequency: {
        type: Sequelize.ENUM('daily', 'weekly', 'quarterly', 'half-yearly'),
        allowNull: false
      },
      description: {
        type: Sequelize.TEXT,
        allowNull: true
      },
      created_at: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      },
      updated_at: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      }
    });

    await queryInterface.createTable('checklist_sections', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      checklist_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'checklists',
          key: 'id'
        }
      },
      title: {
        type: Sequelize.STRING,
        allowNull: false
      },
      order: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0
      },
      created_at: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      },
      updated_at: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      }
    });

    await queryInterface.createTable('checklist_questions', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      section_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'checklist_sections',
          key: 'id'
        }
      },
      question_text: {
        type: Sequelize.STRING,
        allowNull: false
      },
      order: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: 0
      },
      created_at: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      },
      updated_at: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      }
    });

    await queryInterface.createTable('checklist_responses', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      checklist_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'checklists',
          key: 'id'
        }
      },
      user_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'users',
          key: 'id'
        }
      },
      completed_at: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      },
      created_at: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      },
      updated_at: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      }
    });

    await queryInterface.createTable('checklist_answers', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      response_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'checklist_responses',
          key: 'id'
        }
      },
      question_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'checklist_questions',
          key: 'id'
        }
      },
      is_checked: {
        type: Sequelize.BOOLEAN,
        allowNull: false,
        defaultValue: false
      },
      comment: {
        type: Sequelize.TEXT,
        allowNull: true
      },
      updated_by: {
        type: Sequelize.INTEGER,
        allowNull: true,
        references: {
          model: 'users',
          key: 'id'
        }
      },
      created_at: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      },
      updated_at: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      }
    });

    // Seed the initial checklists from the Excel file
    const checklists = [
      { name: 'Daily Check', frequency: 'daily' },
      { name: 'Weekly Check', frequency: 'weekly' },
      { name: 'Quarterly Check', frequency: 'quarterly' },
      { name: 'Half Yearly Check', frequency: 'half-yearly' }
    ];

    await queryInterface.bulkInsert('checklists', checklists);

    // For brevity, I'm showing just a sample of how to seed questions
    // In a real implementation, you'd parse the Excel and seed all questions
    const dailyChecklist = await queryInterface.sequelize.query(
      "SELECT id FROM checklists WHERE name = 'Daily Check' LIMIT 1",
      { type: queryInterface.sequelize.QueryTypes.SELECT }
    );

    if (dailyChecklist.length > 0) {
      const dailyId = dailyChecklist[0].id;


      // Insert sections and questions for Daily Check
      const sections = [
        { checklist_id: dailyId, title: 'Air condition phase 1', order: 1 },
        ...[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29].map(element => {
          return { checklist_id: dailyId, title: `Transformer ${element}`, order: Number(element + 1) }
        }),
        ...[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29].map(element => {
          return { checklist_id: dailyId, title: `Data Container ${element}`, order: Number(element + 30) }
        }),
        ...[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29].map(element => {
          return { checklist_id: dailyId, title: `Dry Cooler ${element}`, order: Number(element + 59) }
        }),
      ];

      await queryInterface.bulkInsert('checklist_sections', sections);

      // Get section IDs to insert questions
      const insertedSections = await queryInterface.sequelize.query(
        "SELECT id, title FROM checklist_sections WHERE checklist_id = ?",
        {
          replacements: [dailyId],
          type: queryInterface.sequelize.QueryTypes.SELECT
        }
      );

      const questions = [];
      for (const section of insertedSections) {
        if (section.title === 'Air condition phase 1') {
          questions.push(
            { section_id: section.id, question_text: 'Motor', order: 1 },
            { section_id: section.id, question_text: 'Frequence conventer', order: 2 },
            { section_id: section.id, question_text: 'Pressure difference', order: 3 }
          );
        } else if (section.title.includes('Transformer')) {
          questions.push(
            { section_id: section.id, question_text: 'Visual check', order: 1 }
          );
        }
        else if (section.title.includes('Data Container')) {
          questions.push(
            { section_id: section.id, question_text: 'No leaks', order: 1 },
            { section_id: section.id, question_text: 'Fans (elect.cabinet)', order: 2 },
            { section_id: section.id, question_text: 'Voltage meters (elect.cabinet)', order: 3 },
            { section_id: section.id, question_text: 'Pressures', order: 4 },
            { section_id: section.id, question_text: 'Miners', order: 5 },
            { section_id: section.id, question_text: 'Pump no extra noise/vibration', order: 6 },
            { section_id: section.id, question_text: 'Fans (back wall)', order: 7 },
            { section_id: section.id, question_text: 'General cleanliness', order: 8 },
            { section_id: section.id, question_text: 'Filling tank level', order: 9 },
          );
        }

        else if (section.title.includes('Dry Cooler')) {
          questions.push(
            { section_id: section.id, question_text: 'Fan', order: 1 },
            { section_id: section.id, question_text: 'Cells', order: 2 },
            { section_id: section.id, question_text: 'Electrical cabinet', order: 3 },
            { section_id: section.id, question_text: 'No abnormal sound/vibration', order: 4 },
            { section_id: section.id, question_text: 'Pipeline', order: 5 },
          );
        }
      }

      await queryInterface.bulkInsert('checklist_questions', questions);
    };


    const weeklyChecklist = await queryInterface.sequelize.query(
      "SELECT id FROM checklists WHERE name = 'Weekly Check' LIMIT 1",
      { type: queryInterface.sequelize.QueryTypes.SELECT }
    );

    if (weeklyChecklist.length > 0) {
      const weeklyId = weeklyChecklist[0].id;
      // Insert sections and questions for Weekly Check
      const sections = [
        ...[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29].map(element => {
          return { checklist_id: weeklyId, title: `Transformer ${element}`, order: Number(element) }
        }),
      ];

      await queryInterface.bulkInsert('checklist_sections', sections);

      // Get section IDs to insert questions
      const insertedSections = await queryInterface.sequelize.query(
        'SELECT id, title FROM checklist_sections WHERE checklist_id = ?',
        {
          replacements: [weeklyId],
          type: queryInterface.sequelize.QueryTypes.SELECT
        }
      );

      const questions = [];
      for (const section of insertedSections) {
        if (section.title.includes('Transformer')) {
          questions.push(
            { section_id: section.id, question_text: 'Visual check MV cabinet', order: 1 },
            { section_id: section.id, question_text: 'Visual check LV cabinet', order: 2 }
          );
        }
      }
      await queryInterface.bulkInsert('checklist_questions', questions);
    }

    const quarterlyChecklist = await queryInterface.sequelize.query(
      "SELECT id FROM checklists WHERE name = 'Quarterly Check' LIMIT 1",
      { type: queryInterface.sequelize.QueryTypes.SELECT }
    );

    if (quarterlyChecklist.length > 0) {
      const quarterlyId = quarterlyChecklist[0].id;
      // Insert sections and questions for Weekly Check
      const sections = [
        ...[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29].map(element => {
          return { checklist_id: quarterlyId, title: `Data Container ${element}`, order: Number(element) }
        }),
      ];

      await queryInterface.bulkInsert('checklist_sections', sections);

      // Get section IDs to insert questions
      const insertedSections = await queryInterface.sequelize.query(
        'SELECT id, title FROM checklist_sections WHERE checklist_id = ?',
        {
          replacements: [quarterlyId],
          type: queryInterface.sequelize.QueryTypes.SELECT
        }
      );

      const questions = [];
      for (const section of insertedSections) {
        if (section.title.includes('Data Container')) {
          questions.push(
            { section_id: section.id, question_text: 'Filter check and cleaning', order: 1 },
            { section_id: section.id, question_text: 'Glycol sample', order: 2 }
          );
        }
      }

      await queryInterface.bulkInsert('checklist_questions', questions);
    }

    const halfYearlyChecklist = await queryInterface.sequelize.query(
      "SELECT id FROM checklists WHERE name = 'Half Yearly Check' LIMIT 1",
      { type: queryInterface.sequelize.QueryTypes.SELECT }
    );

    if (halfYearlyChecklist.length > 0) {
      const halfYearlyId = halfYearlyChecklist[0].id;
      // Insert sections and questions for Weekly Check
      const sections = [
        ...[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29].map(element => {
          return { checklist_id: halfYearlyId, title: `Data Container ${element}`, order: Number(element + 1) }
        })
      ];

      sections.push({ checklist_id: halfYearlyId, title: `Air condition phase 1`, order: 1 })

      await queryInterface.bulkInsert('checklist_sections', sections);

      // Get section IDs to insert questions
      const insertedSections = await queryInterface.sequelize.query(
        'SELECT id, title FROM checklist_sections WHERE checklist_id = ?',
        {
          replacements: [halfYearlyId],
          type: queryInterface.sequelize.QueryTypes.SELECT
        }
      );

      const questions = [];
      for (const section of insertedSections) {
        if (section.title.includes('Data Container')) {
          questions.push(
            { section_id: section.id, question_text: 'Lubrication of bearings', order: 1 },
          );
        }
        else if (section.title.includes('Air condition phase 1')) {
          questions.push(
            { section_id: section.id, question_text: 'Pressure difference', order: 1 },
            { section_id: section.id, question_text: 'Replacement of filters if neseccary', order: 1 },
          );
        }
      }

      await queryInterface.bulkInsert('checklist_questions', questions);
    }
  },


  down: async (queryInterface) => {
    await queryInterface.dropTable('checklist_answers');
    await queryInterface.dropTable('checklist_responses');
    await queryInterface.dropTable('checklist_questions');
    await queryInterface.dropTable('checklist_sections');
    await queryInterface.dropTable('checklists');
  }
};