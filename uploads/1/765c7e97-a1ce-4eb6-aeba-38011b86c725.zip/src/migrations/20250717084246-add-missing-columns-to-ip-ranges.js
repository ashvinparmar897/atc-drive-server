'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.addColumn('ip_ranges', 'locked', {
      type: Sequelize.BOOLEAN,
      defaultValue: false
    });
    await queryInterface.addColumn('ip_ranges', 'agent_id', {
      type: Sequelize.STRING,
      allowNull: true
    });
    await queryInterface.addColumn('ip_ranges', 'container_name', {
      type: Sequelize.STRING,
      allowNull: true
    });
    await queryInterface.addColumn('ip_ranges', 'total_miners', {
      type: Sequelize.INTEGER,
      defaultValue: 0
    });
  },

  async down (queryInterface) {
      await queryInterface.removeColumn('ip_ranges', 'locked');
    await queryInterface.removeColumn('ip_ranges', 'agent_id');
    await queryInterface.removeColumn('ip_ranges', 'container_name');
    await queryInterface.removeColumn('ip_ranges', 'total_miners');

  }
};
