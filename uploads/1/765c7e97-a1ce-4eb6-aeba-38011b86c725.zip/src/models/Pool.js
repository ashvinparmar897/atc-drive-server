module.exports = (sequelize, DataTypes) => {
  const Pool = sequelize.define(
    "Pool",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      miner_mac: {
        type: DataTypes.STRING(50),
        allowNull: false,
        references: {
          model: "miners",
          key: "mac_address",
        },
        unique: true,
      },
      pools: {
        type: DataTypes.JSONB,
        allowNull: false,
        defaultValue: [],
      },
    },
    {
      tableName: "pools",
      timestamps: true,
      createdAt: "created_at",
      updatedAt: "updated_at",
    }
  );

  Pool.associate = (models) => {
    Pool.belongsTo(models.Miner, {
      foreignKey: "miner_mac",
      as: "miner",
    });
  };

  return Pool;
};
