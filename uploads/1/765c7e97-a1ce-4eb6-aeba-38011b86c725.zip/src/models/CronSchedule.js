module.exports = (sequelize, DataTypes) => {
    const CronSchedule = sequelize.define(
        "CronSchedule",
        {
            id: {
                type: DataTypes.INTEGER,
                primaryKey: true,
                autoIncrement: true,
            },
            frequencyDays: {
                type: DataTypes.INTEGER,
                allowNull: false,
                defaultValue: 7,
                validate: {
                    min: 7,
                    max: 365
                }
            },
            lastRun: {
                type: DataTypes.DATE,
                allowNull: true
            }
        },
        {
            tableName: "cron_schedule",
            timestamps: true,
        }
    );

    return CronSchedule;
};