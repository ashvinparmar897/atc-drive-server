// models/Checklist.js
module.exports = (sequelize, DataTypes) => {
    const Checklist = sequelize.define('Checklist', {
        name: {
            type: DataTypes.STRING,
            allowNull: false
        },
        frequency: {
            type: DataTypes.ENUM('daily', 'weekly', 'quarterly', 'half-yearly'),
            allowNull: false
        },
        description: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        content: {
            type: DataTypes.JSONB,
            allowNull: true,
            get() {
                const rawValue = this.getDataValue('content');
                return rawValue ? rawValue?.map(section => ({
                    ...section,
                    section_comment: section?.section_comment || null
                })) : [];
            }
        }
    }, {
        tableName: 'checklists',
        underscored: true,
        timestamps: true
    });

    Checklist.associate = (models) => {
        Checklist.hasMany(models.ChecklistResponse, {
            foreignKey: 'checklist_id',
            as: 'responses'
        });
    };

    return Checklist;
};