module.exports = (sequelize, DataTypes) => {
  const MinerStat = sequelize.define(
    "MinerStat",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      hashrate_current: {
        type: DataTypes.FLOAT,
        comment: "In TH/s",
      },
      hashrate_average: {
        type: DataTypes.FLOAT,
        comment: "In TH/s",
      },
      hashrate_30m: {
        type: DataTypes.FLOAT,
        comment: "In TH/s",
      },
      temperature_values: {
        type: DataTypes.ARRAY(DataTypes.FLOAT),
        defaultValue: [],
      },
      temperature_max: {
        type: DataTypes.FLOAT,
      },
      fan_speeds: {
        type: DataTypes.ARRAY(DataTypes.FLOAT),
        defaultValue: [],
      },
      frequencies: {
        type: DataTypes.ARRAY(DataTypes.FLOAT),
        defaultValue: [],
      },
      hashrates: {
        type: DataTypes.ARRAY(DataTypes.FLOAT),
        defaultValue: [],
      },
      frequency_avg: {
        type: DataTypes.FLOAT,
      },
      active_chains: {
        type: DataTypes.ARRAY(DataTypes.FLOAT),
        defaultValue: [],
      },
      active_chains_info: {
        type: DataTypes.JSON,
        defaultValue: null,
      },
      miner_mac: {
        type: DataTypes.STRING(17),
        allowNull: false,
        unique: true,
        references: {
          model: "miners",
          key: "mac_address",
        },
      },
    },
    {
      tableName: "miner_stats",
      timestamps: true,
      createdAt: "created_at",
      updatedAt: "updated_at",
      indexes: [
        {
          fields: ["miner_mac"],
        },
        {
          fields: ["created_at"],
        },
      ],
    }
  );

  MinerStat.associate = (models) => {
    MinerStat.belongsTo(models.Miner, {
      foreignKey: "miner_mac",
      as: "miner",
    });
  };

  return MinerStat;
};