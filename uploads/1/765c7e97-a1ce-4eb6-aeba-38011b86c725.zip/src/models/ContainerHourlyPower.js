module.exports = (sequelize, DataTypes) => {
    const ContainerHourlyPower = sequelize.define(
        "ContainerHourlyPower",
        {
            id: {
                type: DataTypes.INTEGER,
                primaryKey: true,
                autoIncrement: true,
            },
            date: {
                type: DataTypes.DATEONLY,
                allowNull: false,
            },
            max_power: {
                type: DataTypes.DECIMAL(10, 2),
                allowNull: false,
            },
            is_sent: {
                type: DataTypes.BOOLEAN,
                defaultValue: false,
            },
            sent_at: {
                type: DataTypes.DATE,
                allowNull: true,
            },
        },
        {
            tableName: "container_hourly_power",
            timestamps: true,
            indexes: [
                {
                    unique: true,
                    fields: ['date', 'hour'],
                    name: 'unique_date_hour_index'
                }
            ]
        }
    );

    return ContainerHourlyPower;
};