// models/ChecklistResponse.js
module.exports = (sequelize, DataTypes) => {
    const ChecklistResponse = sequelize.define('ChecklistResponse', {
        completed_at: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: DataTypes.NOW
        },
        content: {
            type: DataTypes.JSONB,
            allowNull: true,
            get() {
                const rawValue = this.getDataValue('content');
                return rawValue ? rawValue?.map(section => ({
                    ...section,
                    section_checked: section?.section_checked || false,
                    section_comment: section?.section_comment || null
                })) : [];
            }
        }
    }, {
        tableName: 'checklist_responses',
        underscored: true,
        timestamps: true
    });

    ChecklistResponse.associate = (models) => {
        ChecklistResponse.belongsTo(models.Checklist, {
            foreignKey: 'checklist_id',
            as: 'checklist'
        });
        ChecklistResponse.belongsTo(models.User, {
            foreignKey: 'user_id',
            as: 'user'
        });
        ChecklistResponse.belongsTo(models.User, {
            foreignKey: 'updated_by',
            as: 'updatedBy'
        });
    };

    return ChecklistResponse;
};