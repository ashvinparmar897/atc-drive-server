module.exports = (sequelize, DataTypes) => {
    const ContainerManualEntry = sequelize.define(
        "ContainerManualEntry",
        {
            id: {
                type: DataTypes.INTEGER,
                primaryKey: true,
                autoIncrement: true,
            },
            start_time: {
                type: DataTypes.DATE,
                allowNull: false,
            },
            end_time: {
                type: DataTypes.DATE,
                allowNull: false,
            },
            power_value: {
                type: DataTypes.DECIMAL(10, 2),
                allowNull: false,
            }
        },
        {
            tableName: "container_manual_entries",
            timestamps: true,
            underscored: false,
            indexes: [
                {
                    unique: true,
                    fields: ['start_time', 'end_time'],
                    name: 'unique_time_slot'
                }
            ]
        }
    );

    return ContainerManualEntry;
};