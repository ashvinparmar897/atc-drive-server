module.exports = (sequelize, DataTypes) => {
  const Miner = sequelize.define(
    "Miner",
    {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      mac_address: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true,
        validate: {
          isMACAddress: true,
        },
      },
      ip: {
        type: DataTypes.STRING(50),
        validate: {
          isIP: true,
        },
      },
      type: {
        type: DataTypes.STRING(50),
        allowNull: false,
      },
      model: {
        type: DataTypes.STRING(50),
      },
      version: {
        type: DataTypes.STRING(50),
      },
      compile_time: {
        type: DataTypes.STRING(100),
      },
      miner_id: {
        type: DataTypes.STRING(50),
      },
      agent_id: {
        type: DataTypes.STRING(50),
      },
      status: {
        type: DataTypes.ENUM("online", "offline", "warning"),
        defaultValue: "online",
      },
    },
    {
      tableName: "miners",
      timestamps: true,
      createdAt: "created_at",
      updatedAt: "updated_at",
      indexes: [
        {
          fields: ["ip"],
        },
        {
          fields: ["miner_id"],
        },
        {
          fields: ["status"],
        },
      ],
    }
  );

  Miner.associate = (models) => {
    Miner.hasMany(models.MinerStat, {
      foreignKey: "miner_mac",
      as: "stats",
    });

    Miner.hasMany(models.Pool, {
      foreignKey: "miner_mac",
      as: "pools",
    });
  };

  return Miner;
};