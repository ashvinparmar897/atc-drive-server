// models/User.js
module.exports = (sequelize, DataTypes) => {
    const User = sequelize.define('User', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        name: {
            type: DataTypes.STRING,
            allowNull: true
        },
        email: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true,
            validate: {
                isEmail: true
            }
        },
        password: {
            type: DataTypes.STRING,
            allowNull: true
        },
        reset_token: {
            type: DataTypes.STRING,
            allowNull: true
        },
        reset_token_expiry: {
            type: DataTypes.BIGINT,
            allowNull: true
        },
        verification_code: {
            type: DataTypes.STRING,
            allowNull: true
        },
        verification_expiry: {
            type: DataTypes.BIGINT,
            allowNull: true
        },
        is_verified: {
            type: DataTypes.BOOLEAN,
            defaultValue: false
        },
        role_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: 'user_roles',
                key: 'id'
            }
        }
    }, {
        tableName: 'users',
        timestamps: true,
        underscored: true,
        defaultScope: {
            attributes: { exclude: ['password', 'reset_token', 'reset_token_expiry', 'verification_code'] }
        },
        scopes: {
            withVerification: {
                attributes: { include: ['verification_code', 'verification_expiry'] }
            }
        }
    });

    User.associate = (models) => {
        User.belongsTo(models.UserRole, {
            foreignKey: 'role_id',
            as: 'role'
        });
    };

    return User;
};