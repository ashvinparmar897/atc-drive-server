module.exports = (sequelize, DataTypes) => {
  const IpRange = sequelize.define('IpRange', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    ip_range: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      comment: 'Example: 172.10.16.0'
    },
    locked: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    agent_id: {
      type: DataTypes.STRING,
      allowNull: true
    },
    container_name: {
      type: DataTypes.STRING,
      allowNull: true
    },
    total_miners: {
      type: DataTypes.INTEGER,
      defaultValue: 0
    },
    miner_manufacturer: {
    type: DataTypes.STRING,
    allowNull: true,
    comment: 'e.g., Bitmain, Whatsminer, Avalon, etc.'
    },
  }, {
    tableName: 'ip_ranges',
    timestamps: true,
    underscored: true
  });

  return IpRange;
};
