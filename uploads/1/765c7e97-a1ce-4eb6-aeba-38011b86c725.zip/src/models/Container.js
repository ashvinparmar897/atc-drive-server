// models/container.js
module.exports = (sequelize, DataTypes) => {
  const Container = sequelize.define(
    "Container",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      container_name: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true,
      },
      temperature: DataTypes.DECIMAL(5, 1),
      humidity: DataTypes.DECIMAL(5, 1),
      pressure_p1: DataTypes.DECIMAL(5, 1),
      pressure_p2: DataTypes.DECIMAL(5, 1),
      pressure_p3: DataTypes.DECIMAL(5, 1),
      pressure_p4: DataTypes.DECIMAL(5, 1),
      pressure_p5: DataTypes.DECIMAL(5, 1),
      hydraulic_pressure_diff: DataTypes.DECIMAL(5, 1),
      filter_pressure_diff: DataTypes.DECIMAL(5, 1),
      temperature_t1: DataTypes.DECIMAL(5, 1),
      temperature_t2: DataTypes.DECIMAL(5, 1),
      temperature_t3: DataTypes.DECIMAL(5, 1),
      temperature_t4: DataTypes.DECIMAL(5, 1),
      frequency: DataTypes.DECIMAL(5, 2),
      inverter_status: DataTypes.INTEGER,
      water_immersion_alarm_1: DataTypes.INTEGER,
      water_immersion_alarm_2: DataTypes.INTEGER,
      abs_filter_pressure_diff: DataTypes.DECIMAL(5, 1),
      total_power: DataTypes.DECIMAL(8, 1),
      updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
      },
      // Dynamically generate electric_meterX_voltage_lY / current_lY
      ...[1, 2, 3, 4, 5, 6].reduce((acc, meter) => {
        ["voltage", "current"].forEach((type) => {
          [1, 2, 3].forEach((line) => {
            const key = `electric_meter${meter}_${type}_l${line}`;
            acc[key] = { type: DataTypes.DECIMAL(6, 1) };
          });
        });
        return acc;
      }, {}),
    },
    {
      tableName: "container_metrics",
      timestamps: false,
      updatedAt: "updated_at",
    }
  );

  // Add initialization method
  Container.initialize = async () => {
    try {
      await Container.sync({ alter: true });
    } catch (error) {
      console.error("Error initializing Container table:", error);
      throw error;
    }
  };

  return Container;
};
