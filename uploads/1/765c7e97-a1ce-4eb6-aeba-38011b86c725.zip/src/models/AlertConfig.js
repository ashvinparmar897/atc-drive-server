module.exports = (sequelize, DataTypes) => {
    const AlertConfig = sequelize.define(
        "AlertConfig",
        {
            id: {
                type: DataTypes.INTEGER,
                primaryKey: true,
                autoIncrement: true,
            },
            field: {
                type: DataTypes.STRING(50),
                allowNull: false,
            },
            displayName: {
                type: DataTypes.STRING(50),
                allowNull: false,
            },
            conditionType: {
                type: DataTypes.ENUM('min', 'max', 'equals', 'notEquals'),
                allowNull: false,
            },
            value: {
                type: DataTypes.DECIMAL(10, 2),
                allowNull: false,
            },
            enabled: {
                type: DataTypes.BOOLEAN,
                defaultValue: true,
            },
        },
        {
            tableName: "alert_configs",
            timestamps: true,
        }
    );
    AlertConfig.initialize = async () => {
        try {
            await AlertConfig.sync({ alter: true });
            await AlertConfig.bulkCreate([
                { field: 'temperature_t1', displayName: 'Temperature T1', conditionType: 'min', value: 40, enabled: true },
                { field: 'temperature_t1', displayName: 'Temperature T1', conditionType: 'max', value: 55, enabled: true },
                { field: 'pressure_p1', displayName: 'Pressure P1', conditionType: 'max', value: 1.6, enabled: true },
                { field: 'pressure_p1', displayName: 'Pressure P1', conditionType: 'min', value: 0.5, enabled: true },
                { field: 'pressure_p2', displayName: 'Pressure P2', conditionType: 'max', value: 1.6, enabled: true },
                { field: 'pressure_p2', displayName: 'Pressure P2', conditionType: 'min', value: 0.5, enabled: true },
                { field: 'pressure_p5', displayName: 'Pressure P5', conditionType: 'max', value: 3.3, enabled: true },
                { field: 'filter_pressure_diff', displayName: 'Filter Pressure Diff', conditionType: 'max', value: 0.7, enabled: true },
                { field: 'inverter_status', displayName: 'Inverter Status', conditionType: 'notEquals', value: 0, enabled: true },
                { field: 'inverter_status', displayName: 'Inverter Status', conditionType: 'notEquals', value: 0, enabled: true },
                [1, 2, 3, 4, 5, 6].forEach((meterNum) => {
                    [1, 2, 3].forEach((lineNum) => {
                        return {
                            field: `electric_meter${meterNum}_voltage_l${lineNum}`, displayName: `Meter ${meterNum} Voltage${lineNum}`, conditionType: 'min', value: 380, enabled: true
                        }
                    })
                })
            ], { ignoreDuplicates: true });
        } catch (error) {
            console.error("Error initializing AlertConfig table:", error);
            throw error;
        }
    };

    return AlertConfig;
};