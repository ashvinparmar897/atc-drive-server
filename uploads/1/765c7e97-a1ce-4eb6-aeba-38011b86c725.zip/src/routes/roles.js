const express = require("express");
const Router = express.Router();

const { getList } = require("../controllers/rolesController");
const authMiddleware = require("../middleware/authMiddleWare");

Router.get("/list", authMiddleware, getList);

module.exports = Router;
