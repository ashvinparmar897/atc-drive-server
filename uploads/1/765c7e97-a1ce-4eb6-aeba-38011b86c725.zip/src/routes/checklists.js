const express = require("express");
const router = express.Router();
const checklistController = require("../controllers/checklistController");
const authMiddleWare = require("../middleware/authMiddleWare");

router.get("/", authMiddleWare, checklistController.getChecklists);
router.get("/:id", authMiddleWare, checklistController.getChecklistDetails);
router.put("/:id", authMiddleWare, checklistController.submitChecklist);

router.get("/user/:id", authMiddleWare, checklistController.getUserResponses);
router.get("/responses/:id", authMiddleWare, checklistController.getResponseDetails);

router.get("/admin/users", authMiddleWare, checklistController.getUsersWithChecklists);
router.put("/answers/:id", authMiddleWare, checklistController.updateAnswers);

module.exports = router;