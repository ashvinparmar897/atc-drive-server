const express = require("express");
const Router = express.Router();
const BitcoinController = require("../controllers/bitcoinController");
const authMiddleware = require("../middleware/authMiddleWare");

Router.get("/price", authMiddleware, BitcoinController.getBitcoinPrice);

module.exports = Router;

module.exports = Router; 