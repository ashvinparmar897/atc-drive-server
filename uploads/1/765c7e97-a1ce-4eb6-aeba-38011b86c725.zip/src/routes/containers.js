const express = require("express");
const Router = express.Router();
const { getList, feedEntries, createSlot, deleteSlots, getUpcomingSlots, getSlots, createBulkSlots, getAlerts, updateAlerts, addAlerts, deleteAlerts, getContainerNames } = require("../controllers/containerController");
const authMiddleware = require("../middleware/authMiddleWare");

Router.get("/list", authMiddleware, getList);
Router.get("/names", authMiddleware, getContainerNames);
Router.post("/manual-entries", authMiddleware, feedEntries);
Router.post("/time-slots", createSlot);
Router.get("/time-slots/tomorrow", authMiddleware, getUpcomingSlots);
Router.delete("/time-slots/:id", authMiddleware, deleteSlots);
Router.post("/create-time-slots", authMiddleware, createBulkSlots);
Router.get("/time-slots", authMiddleware, getSlots);
Router.get("/alert-config", authMiddleware, getAlerts);
Router.put("/alert-config/:id", authMiddleware, updateAlerts);
Router.post("/alert-config", authMiddleware, addAlerts);
Router.delete("/alert-config", authMiddleware, deleteAlerts);







module.exports = Router;
