const express = require("express");
const Router = express.Router();
const PoolController = require("../controllers/poolController");
const authMiddleware = require("../middleware/authMiddleWare");
const { validateTimeRange } = require("../middleware/validation");

Router.get("/timeseries", authMiddleware, validateTimeRange, PoolController.getAllPoolsTimeSeries);
Router.get('/revenue',authMiddleware, PoolController.fetchTotalBTCRevenue);

module.exports = Router; 