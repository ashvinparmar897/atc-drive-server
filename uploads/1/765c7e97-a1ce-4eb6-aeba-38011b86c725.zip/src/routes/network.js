const express = require("express");
const Router = express.Router();
const NetworkService = require("../controllers/networkController");
const authMiddleware = require("../middleware/authMiddleWare");

Router.get("/getProfit", authMiddleware, NetworkService.getProfit);
Router.get("/getStrikePrice", authMiddleware, NetworkService.getStrikePrice);

module.exports = Router;
