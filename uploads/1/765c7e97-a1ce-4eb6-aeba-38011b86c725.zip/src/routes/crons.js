const express = require("express");
const Router = express.Router();
const { UpdateCron, getCron } = require("../controllers/cronController");

Router.get("/schedule", getCron);
Router.put("/schedule", UpdateCron);


module.exports = Router;
