const express = require('express');
const Router = express.Router();
const AuthController = require('../controllers/authController');
const { validateSignup, validateLogin } = require('../middleware/validation');
const authMiddleware = require('../middleware/authMiddleWare');

Router.post('/signup', validateSignup, AuthController.signup);
Router.post('/login', validateLogin, AuthController.login);
Router.get('/me', authMiddleware, AuthController.getCurrentUser);
Router.get('/users', authMiddleware, AuthController.getAllUsers);
Router.get('/users/all', authMiddleware, AuthController.getUsersForAdmin);
Router.put('/users/:id/role', authMiddleware, AuthController.updateUserRole);
Router.post('/refresh-token', AuthController.refreshToken);
Router.post('/request-password-reset', AuthController.requestPasswordReset);
Router.post('/reset-password', AuthController.resetPassword);
Router.get('/validate-role', authMiddleware, AuthController.validateRole);
Router.post('/start-signup', validateSignup, AuthController.startSignup);
Router.post('/complete-signup', AuthController.completeSignup);
Router.post('/resend-verification', AuthController.resendVerification);


module.exports = Router;