const express = require("express");
const Router = express.Router();
const MinerController = require("../controllers/minerControllers");
const authMiddleware = require("../middleware/authMiddleWare");

Router.get("/list", authMiddleware, MinerController.getMinersList);
Router.get('/stats',authMiddleware, MinerController.getMinerDashboardStats);
Router.get('/currentTotalHashrate',authMiddleware, MinerController.getCurrentTotalHashrate);
Router.post("/saveThresholdSettings", authMiddleware, MinerController.saveThreshold);
Router.get("/getThresholdSettings", authMiddleware, MinerController.getThreshold);
Router.get("/getTimeSeriesData", authMiddleware, MinerController.getTimeSeries);
Router.get("/getAllTimeSeriesData", authMiddleware, MinerController.getAllTimeSeries);
Router.get("/getPowerConsumption", authMiddleware, MinerController.getPowerConsumption);
Router.get("/:ip", authMiddleware, MinerController.getMinerDetail);

module.exports = Router;
