const express = require("express");
const Router = express.Router();
const IpRangeController = require("../controllers/ipRangeController");
const authMiddleware = require("../middleware/authMiddleWare");

Router.get("/", authMiddleware, IpRangeController.getAllIpRanges);
Router.post("/", authMiddleware, IpRangeController.createIpRange);
Router.put("/:id", authMiddleware, IpRangeController.updateIpRange);
Router.delete("/:id", authMiddleware, IpRangeController.deleteIpRange);

module.exports = Router;
